//update
$(function () {
  console.log('script.js LOADED');
  $(document).on('click', '.btn-edit', function () {
      $('#idname').val($(this).data('idname'));
      $('#iddes').val($(this).data('iddes'));
      $('#valuename').val($(this).data('name'));
      $('#valuedes').val($(this).data('des'));
      $('#editModal').modal('show');
  });
  $(document).on('submit', '#editForm', function (e) {
      e.preventDefault();
      console.log('SUBMIT KEDETEKSI');
      let data = $(this).serialize();
      console.log('FORM DATA:', data);
      $('#editModal').modal('hide');
      Swal.fire({
          html: '<i class="fa fa-spinner fa-spin"></i> Menyimpan...',
          allowOutsideClick: false,
          showConfirmButton: false
      });
      $.ajax({
          type: 'POST',
          url: 'snmpset.php',
          data: data,
          success: function (res) {
              Swal.close();
              if (res.toLowerCase().includes('berhasil')) {
                  Swal.fire({
                      icon: 'success',
                      title: 'Sukses',
                      text: res
                  });
                  $('.btn-edit[data-idname="' + $('#idname').val() + '"]')
                      .closest('tr')
                      .find('.name-value')
                      .text($('#valuename').val());
              } else {
                  Swal.fire({
                      icon: 'error',
                      title: 'Gagal',
                      text: res
                  });
              }
          },
          error: function () {
              Swal.close();
              Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: 'Gagal menyimpan'
              });
          }
      });
  });
});
//reload
function reloadLaserValue(element, idlaser, idstate, idname) {
  var laserValueText = $(element).find('.laser-value-text').html();
  $(element).addClass('loading');
  $(element).find('.laser-value-text').html('');
  var $this = $(element);
  var $row = $this.closest('tr');
  var $rowsBelow = $row.nextAll();
  $row.find('td').addClass('clicked');
  $rowsBelow.addClass('shifted');
  $.ajax({
    type: "POST",
    url: "snmpset.php",
    data: { idlaser: idlaser, idstate: idstate, idname: idname },
    success: function(data) {
      var result = JSON.parse(data);
      $(element).find('.laser-value-text').html(result.laser);
      $(element).closest('tr').find('.state-value').html(result.state);
      $(element).closest('tr').find('.name-value').html(result.name);
    },
    error: function() {
      $(element).find('.laser-value-text').html(laserValueText);
    },
    complete: function() {
      $(element).removeClass('loading');
      $row.find('td').removeClass('clicked');
      $rowsBelow.removeClass('shifted');
    }
  });
}
//reboot
function rebootOnu(gponOnu, onuName) {
  Swal.fire({
    title: 'Yakin iti reboot ROTER?',
    text: `Gin ne te reboot ${onuName} ine!`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Aok!',
    cancelButtonText: 'Ndak'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        html: '<div class="loading mx-auto"></div>',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        background: 'transparent'
      });
      $.ajax({
        type: 'POST',
        url: 'snmpset.php',
        data: {
          idreboot: gponOnu,
          valuereboot: 1
        },
        success: function(data) {
          Swal.close();
          if (data.includes("Berhasil")) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: `Reboot ${onuName} mantap`,
              showConfirmButton: true,
            })
          } else {
            Swal.fire('Gagal!', data, 'error')
          }
        },
        error: function() {
          Swal.close();
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Cek koneksi juluk!',
          })
        }
      });
    }
  })
}
//reset
function resetOnu(gponOnu, onuName) {
  Swal.fire({
    title: 'Yakin iti reset ROTER?',
    text: `Gin ne te reset ${onuName} ine!`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Aok!',
    cancelButtonText: 'Ndak'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        html: '<div class="loading mx-auto"></div>',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        background: 'transparent'
      });
      $.ajax({
        type: 'POST',
        url: 'snmpset.php',
        data: {
          idreset: gponOnu,
          valuereset: 1
        },
        success: function(data) {
          Swal.close();
          if (data.includes("Berhasil")) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: `Reset ${onuName} mantap`,
              showConfirmButton: true,
            })
          } else {
            Swal.fire('Gagal!', data, 'error')
          }
        },
        error: function() {
          Swal.close();
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Cek koneksi juluk!',
          })
        }
      });
    }
  })
}
//delete
function deleteOnu(gponOnu, onuName) {
  Swal.fire({
    title: 'Yakin iti ngapus ROTER?',
    text: `Gin ne te apus ${onuName} ine!`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Aok!',
    cancelButtonText: 'Ndak'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        html: '<div class="loading mx-auto"></div>',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        background: 'transparent'
      });
      $.ajax({
        type: 'POST',
        url: 'snmpset.php',
        data: {
          iddelete: gponOnu,
          valuedelete: 6
        },
        success: function(data) {
          Swal.close();
          if (data.includes("Berhasil")) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: `wah apus ${onuName} mantap`,
              showConfirmButton: true,
            })
          } else {
            Swal.fire('Gagal!', data, 'error')
          }
        },
        error: function() {
          Swal.close();
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Cek koneksi juluk!',
          })
        }
      });
    }
  })
}
//animasi slidebar
$(document).ready(function () {
  $('#toggle-sidebar').on('click', function (e) {
    e.stopPropagation();
    $('#sidebar').toggleClass('active');
  });
  $(document).on('click', function () {
    if ($(window).width() < 769) {
      $('#sidebar').removeClass('active');
    }
  });
  $('#sidebar').on('click', function (e) {
    e.stopPropagation();
  });
});



//slot
$(document).ready(function () {
  const slotSelect = $("#slotSelect");
  const portSelect = $("#portSelect");

// Fungsi update slotSelect sesuai slots.txt
function updateSlotSelect() {
  $.getJSON("slots.txt?t=" + new Date().getTime(), function(boardData) {
    // Hapus semua opsi kecuali All
    slotSelect.find("option:not([selected])").remove();

    // Tambahkan semua slot (FILTER: hanya GTG*)
    for (const key in boardData) {
      if (boardData.hasOwnProperty(key)) {
        const value = boardData[key];

        if (typeof value === "string" && value.trim() !== "") {
          // FILTER hanya GTG
          if (!value.toUpperCase().startsWith("GTG")) continue;

          slotSelect.append(
            $("<option>", {
              value: key,                 // nomor slot asli
              text: key + "-" + value     // contoh: 1-GTGOG
            })
          );
        }
      }
    }

    // Setelah update slot, reset port select
    portSelect.find("option:not([selected])").remove();

    // Tambahkan event listener untuk slotSelect
    slotSelect.off("change").on("change", function() {
      const selectedText = $("#slotSelect option:selected").text().toUpperCase();
      portSelect.empty(); // kosongkan portSelect

      // Jika slot All
      if ($("#slotSelect").val() === "" || selectedText.includes("ALL")) {
        portSelect.append($("<option>", { value: "", text: "All", selected: true }));
        return;
      }

      let maxPort = 0;
      if (selectedText.includes("GTGO")) maxPort = 8;
      else if (selectedText.includes("GTGH")) maxPort = 16;

      for (let i = 1; i <= maxPort; i++) {
        portSelect.append(
          $("<option>", {
            value: i,
            text: i
          })
        );
      }
    });
  }).fail(function() {
    console.error("Gagal load slots.txt");
  });
}


 

  // tombol nampilin data
  $("#loadData").on("click", function (e) {
    e.preventDefault();

    var $btn = $(this);
    if ($btn.prop("disabled")) return;

    var slot = slotSelect.val(); // "" = ALL SLOT
    var port = portSelect.val(); // "" = ALL PORT

    var slotEmpty = (slot === "" || slot === null);
    var portEmpty = (port === "" || port === null);

    var targetUrl = slotEmpty && portEmpty ? "tabel_dataori.php" : "tabel_data.php";

    $btn.addClass("btn-animate");
    setTimeout(function () { $btn.removeClass("btn-animate"); }, 300);

    $btn.prop("disabled", true)
        .addClass("btn-loading")
        .html('<i class="fa fa-spinner fa-spin"></i> Loading...');

    $.ajax({
      url: targetUrl,
      method: "GET",
      data: { slot: slot, port: port },
      dataType: "html",
      success: function (response) {
        $("#hasilData").html(response);

        // 🔄 Setelah load dataori.php, update slotSelect otomatis
        if(targetUrl === "tabel_dataori.php") {
          updateSlotSelect();
        }
      },
      error: function (xhr, status, err) {
        console.error("AJAX Error:", status, err);
        $("#hasilData").html("<div style='color:red'>Gagal memuat data. Cek console (F12).</div>");
      },
      complete: function () {
        $btn.prop("disabled", false)
            .removeClass("btn-loading")
            .html('<i class="fa fa-table"></i> Cek Wah');
      }
    });
  });
});






// Board + Ports + CRUD
document.addEventListener('DOMContentLoaded', function() {
  const slotSelect = document.getElementById('slotSelect');
  const portSelect = document.getElementById('portSelect');

// Fungsi baca ports.txt tanpa cache browser
function getPorts(callback){
  const url = 'ports.txt?t=' + new Date().getTime(); // Tambahkan timestamp untuk mencegah cache
  fetch(url)
      .then(res => res.text())
      .then(text => {
          const data = {};
          text.split(/\r?\n/).forEach(line => {
              if(line.trim() !== ''){
                  const parts = line.split('|');
                  if(parts.length == 2) data[parts[0]] = parts[1];
              }
          });
          callback(data);
      })
      .catch(() => callback({}));
}


  // Ambil boardData dari slots.txt
  const url = 'slots.txt?t=' + new Date().getTime(); // Tambahkan timestamp untuk mencegah cache
  fetch(url)
      .then(res => res.json())
      .then(boardData => {

          // Hapus semua opsi kecuali selected (All)
          slotSelect.querySelectorAll('option:not([selected])').forEach(e => e.remove());
          portSelect.querySelectorAll('option:not([selected])').forEach(e => e.remove());

          // Tambahkan slot dari object
          for (const key in boardData) {
              if (boardData.hasOwnProperty(key)) {
                  const value = boardData[key];
                  if (value && value.trim() !== '') {
                      // Filter: hanya tampilkan slot GTG*
                      if (!value.toUpperCase().startsWith("GTG")) continue;

                      const option = document.createElement('option');
                      option.value = key; // gunakan nomor sebagai value
                      option.textContent = key + ' ' + value; // tampilkan nomor + nama
                      slotSelect.appendChild(option);
                  }
              }
          }

// Update port select
function updatePorts(){
  const slotValue = slotSelect.value;

  // ===== SLOT ALL → PORT HANYA ALL =====
  if(slotValue === "" || slotValue === "All"){
      portSelect.innerHTML = '<option value="" selected>All</option>';
      return;
  }

  // ===== SLOT DIPILIH → HILANGKAN ALL =====
  portSelect.innerHTML = '';

  getPorts(function(data){
      // Ambil nama slot dari text
      const slotText = slotSelect.options[slotSelect.selectedIndex]
          .text.split(' ')[1].toUpperCase();

      // Tentukan maxPort sesuai slot
      let maxPort = 16;
      if(slotText.includes("GTGO") || slotText.includes("GTGOG")) maxPort = 8;
      else if(slotText.includes("GTGH") || slotText.includes("GTGHG")) maxPort = 16;

      // Loop port (TANPA ALL)
      for(let i=1;i<=maxPort;i++){
          const keyPort = slotValue + "-" + i;
          const name = data[keyPort] ? data[keyPort] : "";
          const option = document.createElement('option');
          option.value = i;
          option.textContent = i + (name ? " - " + name : "");
          portSelect.appendChild(option);
      }

      // ===== DEFAULT PORT 1 =====
      portSelect.value = "1";
  });
}



          // Event slot berubah
          slotSelect.addEventListener('change', updatePorts);

          // Trigger awal
          updatePorts();
      })
      .catch(err => console.error('Gagal load slots.txt', err));

  // Modal buka port
  document.getElementById("openPortModal").addEventListener('click', function(){
      const slot = slotSelect.value;
      const port = portSelect.value;

      if(!slot || !port){
          alert("Pilen slot dait port juluk!");
          return;
      }

      document.getElementById("modalPortLabel").textContent = "Slot "+slot+" - Port "+port;

      getPorts(function(data){
          const key = slot+"-"+port;
          document.getElementById("portName").value = data[key] ? data[key] : "";
          document.getElementById("portModal").style.display = "flex";
      });
  });

  // Tutup modal
  document.getElementById("closePortModal").addEventListener('click', function(){
      document.getElementById("portModal").style.display = "none";
  });

  // CRUD modal
  function sendPortData(action){
      const slot = slotSelect.value;
      const port = portSelect.value;
      const name = document.getElementById("portName").value.trim();

      if(!slot || !port){
          alert("Slot dan Port wajib!");
          return;
      }
      if((action==="create" || action==="update") && !name){
          alert("Nama wajib diisi!");
          return;
      }

      let payload = {};
      if(action==="create") payload = {slot:slot, port:port, name:name};
      if(action==="delete") payload = {delete:true, key:slot+"-"+port};

      fetch('update.php',{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify(payload)
      })
      .then(res => res.text())
      .then(resText => {
          alert(resText);
          document.getElementById("portName").value = "";
          document.getElementById("portModal").style.display = "none";
          // Refresh port list sesuai slot & ports.txt
          slotSelect.dispatchEvent(new Event('change'));
      });
  }

  document.getElementById("createPort").addEventListener('click', function(){ sendPortData("create"); });
  document.getElementById("deletePort").addEventListener('click', function(){
      if(confirm("Hapus port ini?")) sendPortData("delete");
  });

});












//tiket gangguan
$(document).ready(function(){
  // ========================
  // Tambah Tiket
  // ========================
  $('#showAddTicketFormBtn').on('click', function(){
      $('#addTicketFormContainer').toggle();
  });
  $('#addTicketFormInline').submit(function(e){
      e.preventDefault();
      $.ajax({
          url: 'update_ticket.php',
          type: 'POST',
          data: $(this).serialize(),
          success: function(res){
              if(res.trim() === 'success_add'){
                  Swal.fire({
                      title: 'Berhasil!',
                      text: 'Tiket berhasil ditambahkan',
                      icon: 'success',
                      showConfirmButton: false,
                      timer: 1000
                  });
                  $('#addTicketFormInline')[0].reset();
                  $('#addTicketFormContainer').hide();
                  loadTickets();
              } else {
                  Swal.fire('Error!', 'Gagal menambahkan tiket', 'error');
              }
          },
          error: function(){
              Swal.fire('Error!', 'Gagal menambahkan tiket', 'error');
          }
      });
  });
  // ========================
  // Edit Tiket
  // ========================
  $(document).on('click', '.editTicketBtn', function(){
      let id = $(this).data('id');
      let title = $(this).data('title');
      let description = $(this).data('description');

      $('#updateTicketId').val(id);
      $('#updateTitle').val(title);
      $('#updateDescription').val(description);
      $('#updateTicketModal').modal('show');
  });
  $('#updateTicketForm').submit(function(e){
      e.preventDefault();
      $.ajax({
          url: 'update_ticket.php',
          type: 'POST',
          data: $(this).serialize(),
          success: function(response){
              if(response.trim() === 'success_update'){
                  Swal.fire({
                      title: 'Berhasil!',
                      text: 'Tiket berhasil diupdate',
                      icon: 'success',
                      showConfirmButton: false,
                      timer: 1000
                  });
                  $('#updateTicketModal').modal('hide');
                  loadTickets();
              } else {
                  Swal.fire('Gagal!', 'Terjadi kesalahan saat update tiket', 'error');
              }
          },
          error: function(){
              Swal.fire('Error!', 'Terjadi kesalahan saat update tiket', 'error');
          }
      });
  });
  // ========================
  // Hapus Tiket
  // ========================
  $(document).on('click', '.deleteTicketBtn', function(){
      let id = $(this).data('id');

      Swal.fire({
          title: 'Yakin ingin menghapus?',
          text: "Tiket akan dihapus permanen!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Hapus',
          cancelButtonText: 'Batal'
      }).then((result) => {
          if(result.isConfirmed){
              $.ajax({
                  url: 'update_ticket.php',
                  type: 'POST',
                  data: {iddelete: id},
                  success: function(res){
                      if(res.trim() === 'success_delete'){
                          Swal.fire({
                              title: 'Berhasil!',
                              text: 'Tiket berhasil dihapus',
                              icon: 'success',
                              showConfirmButton: false,
                              timer: 1000
                          });
                          loadTickets();
                      } else {
                          Swal.fire('Error!', 'Gagal menghapus tiket', 'error');
                      }
                  },
                  error: function(){
                      Swal.fire('Error!', 'Gagal menghapus tiket', 'error');
                  }
              });
          }
      });
  });

  // ========================
  // Lihat Tiket
  // ========================
  $('#viewTicketBtn').click(function(){
    $('#viewTicketModal').modal('show');
    loadTickets();
});
  function loadTickets(){
    $.ajax({
        url: 'update_ticket.php',
        type: 'GET',
        success: function(data){
            $('#ticketList').html(data);
        },
        error: function(){
            Swal.fire('Error!', 'Gagal memuat daftar tiket', 'error');
        }
    });
}
$(document).ready(function(){
  // Fix nested modal scroll hilang
  $('#updateTicketModal').on('hidden.bs.modal', function () {
      if($('.modal.show').length) {
          $('body').addClass('modal-open');
      }
  });
});

});

//about
$(document).ready(function(){
  $('#viewabtBtn').on('click', function(e){
      e.preventDefault();
      $('#aboutModal').modal('show'); // Bootstrap 4 style
  });
});


// ================= MEMANGGIL DATA SSID + WPA2 DARI SERVER =================
$.ajax({
  url: 'telnet.php',
  type: 'POST',
  dataType: 'json',
  data: { showallssid: gpononu }, // satu request untuk SSID + auth
  success: function(res) {
      if (res.ssids) {
          let ssidData = res.ssids;

          // ================= ENABLE SELECT =================
          $('#ssidIndex').prop('disabled', false);
          $('#ssidState').prop('disabled', false);
          $('#passIndex').prop('disabled', false);

          // ================= ISI SELECT SSID =================
          $('#ssidIndex').empty();
          $.each(ssidData, function(i, ssid) {
              $('#ssidIndex').append(
                  $('<option>', {
                      value: ssid.index,
                      text: ssid.name
                  })
              );
          });

          // ================= ISI SELECT PASS WPA2 =================
          $('#passIndex').empty();
          $.each(ssidData, function(i, ssid) {
              $('#passIndex').append(
                  $('<option>', {
                      value: ssid.index,
                      text: ssid.name + " - " + (ssid.auth || ''),
                      'data-auth': ssid.auth || ''
                  })
              );
          });

          // ================= SET DEFAULT =================
          let defaultIndex = 1;
          $('#ssidIndex').val(defaultIndex);
          $('#ssidSetting').val(ssidData[defaultIndex].name || '');
          $('#passIndex').val(defaultIndex);
          $('#passWpa2Setting').val($('#passIndex option:selected').data('auth') || '');

          // ================= EVENT CHANGE SSID =================
          $('#ssidIndex').off('change').on('change', function() {
              let idx = $(this).val();
              $('#ssidSetting').val(ssidData[idx] ? ssidData[idx].name : '');
          });

          // ================= EVENT CHANGE PASS =================
          $('#passIndex').off('change').on('change', function() {
              let selected = $('#passIndex option:selected');
              $('#passWpa2Setting').val(selected.data('auth') || '');
          });
      }
  },
  error: function() {
      $('#ssidSetting').val('');
      $('#ssidIndex').prop('disabled', true);
      $('#ssidState').prop('disabled', true);
      $('#passWpa2Setting').val('');
      $('#passIndex').prop('disabled', true);
  }
});



function openRemoteModal(gpononu, name) {

  // ================= INFO ONU =================
  $('#remoteInfo').html('<b>' + name + '</b><br>SLOT ONU: ' + gpononu);
  $('#remoteInfo').data('onu', gpononu);
  $('#remoteInfo').data('name', name);

  // ================= RESET FORM =================
  $('#remoteState').val('');
  $('#ssidSetting').val('');
  $('#ssidIndex').val('1');
  // Jangan ubah #ssidState
  $('#passWpa2Setting').val('');

// ================= SHOW STATUS REMOTE =================
showRemoteStatus(gpononu);

// ================= LOAD ALL SSID + PASSWORD =================
$('#ssidSetting').val('Loading...');
$('#ssidIndex').prop('disabled', true);
$('#ssidState').prop('disabled', true);
$('#passWpa2Setting').val('Loading...');

let ssidData = {};

$.ajax({
    url: 'telnet.php',
    type: 'POST',
    dataType: 'json',
    data: { showallssid: gpononu },
    success: function(res) {
        if (res.ssids) {
            ssidData = res.ssids;

            // ================= ENABLE SELECT =================
            $('#ssidIndex').prop('disabled', false);
            $('#ssidState').prop('disabled', false);

            // ================= ISI SELECT SSID =================
            $('#ssidIndex').empty();
            for (let i = 1; i <= 8; i++) {
                $('#ssidIndex').append(
                    $('<option>', { value: i, text: 'SSID' + i })
                );
            }

            // ================= SET DEFAULT SSID & STATE =================
            let defaultIndex = 1; // SSID1
            $('#ssidIndex').val(defaultIndex);
            $('#ssidSetting').val(ssidData[defaultIndex] ? ssidData[defaultIndex].name : '');
            $('#passWpa2Setting').val(ssidData[defaultIndex] ? ssidData[defaultIndex].auth : '');

            // Default state: enable untuk SSID1 & SSID5
            if (defaultIndex == 1 || defaultIndex == 5) {
                $('#ssidState').val('enable');
            } else {
                $('#ssidState').val('disable');
            }

            // ================= EVENT CHANGE SSID =================
            $('#ssidIndex').off('change').on('change', function() {
                let idx = $(this).val();
                $('#ssidSetting').val(ssidData[idx] ? ssidData[idx].name : '');
                $('#passWpa2Setting').val(ssidData[idx] ? ssidData[idx].auth : '');

                // Set default ssidState ketika ganti SSID
                if (idx == '1' || idx == '5') {
                    $('#ssidState').val('enable');
                } else {
                    $('#ssidState').val('disable');
                }
            });

        } else {
            $('#ssidSetting').val('');
            $('#ssidIndex').prop('disabled', true);
            $('#ssidState').prop('disabled', true);
            $('#passWpa2Setting').val('');
        }
    },
    error: function() {
        $('#ssidSetting').val('');
        $('#ssidIndex').prop('disabled', true);
        $('#ssidState').prop('disabled', true);
        $('#passWpa2Setting').val('');
    }
});


  // ================= SUBMIT =================
  $('#btnSubmitRemote').off('click').on('click', function () {
      const $btn = $(this);
      if ($btn.prop('disabled')) return;

      $btn.prop('disabled', true).text('Processing...');

      // Ambil nilai dari modal
      let gpononu     = $('#remoteInfo').data('onu');
      let name        = $('#remoteInfo').data('name');
      let remoteState = $('#remoteState').val();
      let ssidName    = $('#ssidSetting').val().trim();
      let ssidIndex   = $('#ssidIndex').val();
      let ssidState   = $('#ssidState').val(); // tetap sesuai pilihan
      let passWpa2    = $('#passWpa2Setting').val().trim();

      let hasAction = false;
      let ajaxJobs = [];

      // ================= REMOTE =================
      if (remoteState === 'on') { ajaxJobs.push(remoteOn(gpononu, name)); hasAction = true; }
      if (remoteState === 'off'){ ajaxJobs.push(remoteOff(gpononu, name)); hasAction = true; }

      // ================= SSID & PASSWORD =================
      if (ssidName !== '' || passWpa2 !== '') {
          if (passWpa2 !== '' && passWpa2.length < 8){
              Swal.fire('Peringatan', 'Password WPA2 minimal 8 karakter', 'warning');
              unlock();
              return;
          }
          ajaxJobs.push(
              $.ajax({
                  url: 'telnet.php',
                  type: 'POST',
                  data: {
                      setssidpass: gpononu,
                      ssid: ssidName,
                      pass: passWpa2,
                      ssidindex: ssidIndex,
                      ssidstate: ssidState // LOCK/UNLOCK sesuai pilihan
                  }
              })
          );
          hasAction = true;
      }

      if(!hasAction){
          Swal.fire('Info', 'Tidak ada aksi yang dipilih', 'info');
          unlock();
          return;
      }

      // ================= TUNGGU SEMUA SELESAI =================
      $.when.apply($, ajaxJobs)
          .done(function () {
              Swal.fire('Sukses', 'Perintah berhasil dikirim ke OLT', 'success');
              $('#remoteModal').modal('hide');
          })
          .fail(function () {
              Swal.fire('Error', 'Salah satu proses gagal', 'error');
          })
          .always(function () {
              unlock();
          });

      function unlock() {
          $btn.prop('disabled', false).text('Submit');
      }
  });

  // ================= SHOW MODAL =================
  $('#remoteModal').modal('show');
}



function showRemoteStatus(gpononu) {

  // ================= RESET MAC =================
  $('#remoteMacText')
      .removeClass()
      .addClass('text-secondary')
      .html('MAC: Loading...');

  // ================= RESET STATUS =================
  $('#remoteStatusText')
      .removeClass()
      .addClass('text-secondary')
      .text('Loading...');

  // ================= RESET IP =================
  $('#remoteIpText').html('IP: Loading...');

  // ================= HELPER FORMAT MAC (LOCAL) =================
  function formatMacZte(mac) {
      // contoh: 3ecb.b172.5b8b → 3E:CB:B1:72:5B:8B
      mac = mac.replace(/\./g, '').toUpperCase();
      return mac.match(/.{1,2}/g).join(':');
  }

  $.ajax({
      url: 'telnet.php',
      type: 'POST',
      dataType: 'json',
      data: { showidremote: gpononu },

      success: function(res) {

          // ================= MAC ADDRESS =================
          if (res.total_mac > 0 && res.macs && res.macs.length > 0) {

              let macList = res.macs.map(mac => {
                  return `<span class="badge mr-1" style="background:#6f42c1;color:#fff;">
                              ${formatMacZte(mac)}
                          </span>`;
              }).join('');

              $('#remoteMacText')
                  .removeClass()
                  .addClass('text-info')
                  .html(`Total MAC: <b>${res.total_mac}</b><br>${macList}`);

          } else {
              $('#remoteMacText')
                  .removeClass()
                  .addClass('text-muted')
                  .html('Total MAC: 0');
          }

          // ================= STATUS REMOTE =================
          if (res.status === 'on') {
              $('#remoteStatusText')
                  .removeClass()
                  .addClass('text-success')
                  .text('REMOTE ON');
              $('#remoteState').val('on');
          } else {
              $('#remoteStatusText')
                  .removeClass()
                  .addClass('text-danger')
                  .text('REMOTE OFF');
              $('#remoteState').val('off');
          }

          // ================= IP SEBAGAI LINK =================
          if (res.ip && res.ip.length > 0) {
              let links = res.ip.map(ip =>
                  `<a href="http://${ip}" target="_blank" class="mr-1">${ip}</a>`
              );
              $('#remoteIpText').html('IP: ' + links.join(', '));
          } else {
              $('#remoteIpText').text('IP: -');
          }
      },

      error: function() {
          $('#remoteMacText')
              .removeClass()
              .addClass('text-warning')
              .text('MAC: gagal load');

          $('#remoteStatusText')
              .removeClass()
              .addClass('text-warning')
              .text('Gagal cek status');

          $('#remoteIpText').text('IP: -');
      }
  });
}


























//remoteon
function remoteOn(gponOnu, onuName) {

  // WAJIB return $.ajax
  return $.ajax({
      type: 'POST',
      url: 'telnet.php',
      data: { idremoteon: gponOnu }
  })
  .done(function () {
      // update status setelah sukses
      showRemoteStatus(gponOnu);
  })
  .fail(function () {
      // diam saja (tanpa popup)
      console.log('Remote ON gagal');
  });

}



//remoteoff
function remoteOff(gponOnu, onuName) {

  // WAJIB return $.ajax
  return $.ajax({
      type: 'POST',
      url: 'telnet.php',
      data: { idremoteoff: gponOnu }
  })
  .done(function () {
      // update status setelah sukses
      showRemoteStatus(gponOnu);
  })
  .fail(function () {
      // diam saja
      console.log('Remote OFF gagal');
  });

}
