<?php
require 'vendor/autoload.php';
require 'koneksi.php';
use FreeDSx\Snmp\SnmpClient;


function getState() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
        'version' => 2,
    ]);

    $oid = '1.3.6.1.4.1.3902.1082.500.10.2.3.8.1.4';

    $total = [
        'working' => 0,
        'dyinggasp' => 0,
        'los' => 0,
        'offline' => 0
    ];

    $data = [];

    try {
        $walk = $snmp->walk($oid);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            // === AMBIL INDEX STRING ===
            $fullOid   = $oidValue->getOid();
            $baseindex = str_replace($oid . '.', '', $fullOid);

            // === AMBIL INTEGER VALUE (FreeDSx SAFE) ===
            $valueObj = $oidValue->getValue();
            $nilai = is_object($valueObj)
                ? (int) $valueObj->getValue()
                : (int) $valueObj;

            // === MAPPING STATUS ===
            switch ($nilai) {
                case 4:
                    $status = 'Working';
                    $total['working']++;
                    break;
                case 5:
                    $status = 'DyingGasp';
                    $total['dyinggasp']++;
                    break;
                case 2:
                    $status = 'LOS';
                    $total['los']++;
                    break;
                case 7:
                    $status = 'OFFLINE';
                    $total['offline']++;
                    break;
                default:
                    $status = 'Unknown';
                    break;
            }

            // === FILTER: SKIP WORKING ===
            if ($status === 'Working') {
                continue;
            }

            // === SIMPAN YANG NON-WORKING SAJA ===
            $data[$baseindex] = [
                'nilai'  => $nilai,
                'status' => $status
            ];
        }
    } catch (\Exception $e) {
        $data['error'] = 'Gagal mengambil data SNMP';
    }

    $output = [
        'state' => $data,
        'total' => array_merge($total, [
            'all' => $total['working'] + $total['dyinggasp'] + $total['los'] + $total['offline']
        ])
    ];

    file_put_contents(
        'state.txt',
        json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
    );

    return $output;
}

function getState2() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
        'version' => 2,
    ]);

    $oid = '1.3.6.1.4.1.3902.1082.500.10.2.3.8.1.4';

    $total = [
        'working' => 0,
        'dyinggasp' => 0,
        'los' => 0,
        'offline' => 0
    ];

    $data = [];

    try {
        $walk = $snmp->walk($oid);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            // === AMBIL INDEX STRING ===
            $fullOid   = $oidValue->getOid();
            $baseindex = str_replace($oid . '.', '', $fullOid);

            // === AMBIL INTEGER VALUE (FreeDSx SAFE) ===
            $valueObj = $oidValue->getValue();
            $nilai = is_object($valueObj)
                ? (int) $valueObj->getValue()
                : (int) $valueObj;

            // === MAPPING STATUS ===
            switch ($nilai) {
                case 4:
                    $status = 'Working';
                    $total['working']++;
                    break;
                case 5:
                    $status = 'DyingGasp';
                    $total['dyinggasp']++;
                    break;
                case 2:
                    $status = 'LOS';
                    $total['los']++;
                    break;
                case 7:
                    $status = 'OFFLINE';
                    $total['offline']++;
                    break;
                default:
                    $status = 'Unknown';
                    break;
            }

            // === FILTER: SKIP WORKING ===
            if ($status === 'Working') {
                continue;
            }

            // === SIMPAN YANG NON-WORKING SAJA ===
            $data[$baseindex] = [
                'nilai'  => $nilai,
                'status' => $status
            ];
        }
    } catch (\Exception $e) {
        $data['error'] = 'Gagal mengambil data SNMP';
    }

    $output = [
        'state' => $data,
        'total' => array_merge($total, [
            'all' => $total['working'] + $total['dyinggasp'] + $total['los'] + $total['offline']
        ])
    ];

    return $output;
}


function getName() {
    global $ip, $port, $community;

    // =============================
    // BACA INDEX DARI state.txt
    // =============================
    if (!file_exists('state.txt')) {
        return ['error' => 'state.txt tidak ditemukan'];
    }

    $stateJson = json_decode(file_get_contents('state.txt'), true);
    if (!isset($stateJson['state'])) {
        return ['error' => 'Format state.txt salah'];
    }

    // daftar index baseindex.onuid
    $targetIndex = array_flip(array_keys($stateJson['state']));

    // =============================
    // INIT SNMP
    // =============================
    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    $BASE_OID = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2';

    $data = [];
    $no = 1;

    try {
        // =============================
        // WALK BASE OID (walkNext)
        // =============================
        $walk = $snmp->walk($BASE_OID);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            $fullOid = $oidValue->getOid();
            // ambil index setelah BASE_OID.
            if (strpos($fullOid, $BASE_OID . '.') !== 0) {
                continue;
            }

            $index = substr($fullOid, strlen($BASE_OID) + 1);

            // hanya proses index yg ada di state.txt
            if (!isset($targetIndex[$index])) {
                continue;
            }

            $valObj = $oidValue->getValue();
            $name   = is_object($valObj) && method_exists($valObj, 'getValue')
                ? trim((string)$valObj->getValue())
                : trim((string)$valObj);

            $data[$index] = [
                'no'   => $no,
                'name' => $name
            ];

            $no++;
        }

    } catch (\Exception $e) {
        return ['error' => 'SNMP error: ' . $e->getMessage()];
    }

    // =============================
    // ISI YANG TIDAK KETEMU
    // =============================
    foreach ($targetIndex as $idx => $v) {
        if (!isset($data[$idx])) {
            $data[$idx] = [
                'no'   => $no,
                'name' => 'Tidak ada data'
            ];
            $no++;
        }
    }

//    file_put_contents(
//        'onu_name_from_state.txt',
//        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
//    );

    return $data;
}



function getGpononu() {

    // =============================
    // BACA FILE onu_index_map.txt
    // =============================
    if (!file_exists('onu_index_map.txt')) {
        return ['error' => 'onu_index_map.txt tidak ditemukan'];
    }

    $json = json_decode(file_get_contents('onu_index_map.txt'), true);
    if (!is_array($json)) {
        return ['error' => 'Format onu_index_map.txt salah'];
    }

    // =============================
    // OPTIONAL: FILTER INDEX DARI state.txt
    // =============================
    $targetIndex = [];
    if (file_exists('state.txt')) {
        $state = json_decode(file_get_contents('state.txt'), true);
        if (isset($state['state'])) {
            $targetIndex = array_flip(array_keys($state['state']));
        }
    }

    $data = [];
    $no = 1;

    foreach ($json as $onuIndex => $info) {

        // jika pakai filter state.txt
        if (!empty($targetIndex) && !isset($targetIndex[$onuIndex])) {
            continue;
        }

        if (!isset($info['interface'])) {
            continue;
        }

        $data[$onuIndex] = [
            'no'    => $no++,
            'nilai' => $info['interface'] // gpon-onu_1/x/x:x
        ];
    }

    // =============================
    // SIMPAN KE FILE TXT
    // =============================
//    file_put_contents(
//        'gpononu_from_state.txt',
//        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
//    );

    return $data;
}








function getSn() {
    global $ip, $port, $community;

    // =============================
    // BACA INDEX DARI state.txt
    // =============================
    if (!file_exists('state.txt')) {
        return ['error' => 'state.txt tidak ditemukan'];
    }

    $stateJson = json_decode(file_get_contents('state.txt'), true);
    if (!isset($stateJson['state'])) {
        return ['error' => 'Format state.txt salah'];
    }

    // daftar index baseindex.onuid
    $targetIndex = array_flip(array_keys($stateJson['state']));

    // =============================
    // INIT SNMP
    // =============================
    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    // OID SERIAL NUMBER ONU
    $BASE_OID = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.18';

    $data = [];
    $no = 1;

    try {
        // =============================
        // WALK BASE OID (walkNext)
        // =============================
        $walk = $snmp->walk($BASE_OID);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            $fullOid = $oidValue->getOid();

            // pastikan masih subtree SN
            if (strpos($fullOid, $BASE_OID . '.') !== 0) {
                continue;
            }

            // ambil index baseindex.onuid
            $index = substr($fullOid, strlen($BASE_OID) + 1);

            // hanya ONU yg ada di state.txt
            if (!isset($targetIndex[$index])) {
                continue;
            }

            $valObj = $oidValue->getValue();

            // ambil STRING SN dari FreeDSx
            $sn = is_object($valObj) && method_exists($valObj, 'getValue')
                ? (string)$valObj->getValue()
                : (string)$valObj;

            // buang prefix angka + koma (misal: "8,48575443")
            $sn = preg_replace('/^\d+,/', '', trim($sn));

            $data[$index] = [
                'no' => $no,
                'sn' => $sn
            ];

            $no++;
        }

    } catch (\Exception $e) {
        return ['error' => 'SNMP error: ' . $e->getMessage()];
    }

    // =============================
    // INDEX YANG TIDAK KETEMU
    // =============================
    foreach ($targetIndex as $idx => $v) {
        if (!isset($data[$idx])) {
            $data[$idx] = [
                'no' => $no,
                'sn' => 'Tidak ada data'
            ];
            $no++;
        }
    }

    // =============================
    // SIMPAN KE FILE
    // =============================
//    file_put_contents(
//        'onu_sn_from_state.txt',
//        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
//    );

    return $data;
}






function getLaser() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    $baseOid = '1.3.6.1.4.1.3902.1082.500.20.2.2.2.1.10';
    $result = [];

    try {
        $walk = $snmp->walk($baseOid);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();
            $fullOid = (string)$oidValue->getOid();
            $raw = $oidValue->getValue()->getValue();

            // Ambil index: 3 segmen terakhir tapi hapus .1 terakhir
            $parts = explode('.', $fullOid);
            $len = count($parts);
            $index = $parts[$len-3] . '.' . $parts[$len-2];

            // Konversi RX
            if ($raw < 32768) {
                $rx = ($raw * 0.002) - 30.0;
            } elseif ($raw > 32767 && $raw < 65535) {
                $rx = (-30 - ((65535 - $raw) * 0.002));
            } else {
                continue;
            }

            // Filter nilai ≤ -28
            if ($rx <= -28) {
                $result[$index] = [
                    "nilai" => (string) round($rx, 2)
                ];
            }
        }

    } catch (\Exception $e) {
        // abaikan error
    }

    // Simpan JSON ke file seperti biasa
    $json = json_encode($result, JSON_PRETTY_PRINT);
    file_put_contents('redamantinggi.txt', $json);

    return $result; // kembalikan array untuk Telegram bot
}






function getName2() {
    global $ip, $port, $community;

    // =============================
    // BACA INDEX DARI redamantinggi.txt
    // =============================
    if (!file_exists('redamantinggi.txt')) {
        return ['error' => 'redamantinggi.txt tidak ditemukan'];
    }

    $laserJson = json_decode(file_get_contents('redamantinggi.txt'), true);
    if (!is_array($laserJson)) {
        return ['error' => 'Format redamantinggi.txt salah'];
    }

    // daftar index yang akan diambil
    $targetIndex = array_flip(array_keys($laserJson));

    // =============================
    // INIT SNMP
    // =============================
    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    $BASE_OID = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2'; // OID Nama

    $data = [];
    $no = 1;

    try {
        // =============================
        // WALK BASE OID
        // =============================
        $walk = $snmp->walk($BASE_OID);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();
            $fullOid = (string)$oidValue->getOid();

            // ambil index setelah BASE_OID
            if (strpos($fullOid, $BASE_OID . '.') !== 0) {
                continue;
            }

            $index = substr($fullOid, strlen($BASE_OID) + 1);

            // hanya proses index yg ada di redamantinggi.txt
            if (!isset($targetIndex[$index])) {
                continue;
            }

            $valObj = $oidValue->getValue();
            $name   = is_object($valObj) && method_exists($valObj, 'getValue')
                ? trim((string)$valObj->getValue())
                : trim((string)$valObj);

            $data[$index] = [
                'no'   => $no,
                'name' => $name
            ];

            $no++;
        }

    } catch (\Exception $e) {
        return ['error' => 'SNMP error: ' . $e->getMessage()];
    }

    // =============================
    // ISI YANG TIDAK KETEMU
    // =============================
    foreach ($targetIndex as $idx => $v) {
        if (!isset($data[$idx])) {
            $data[$idx] = [
                'no'   => $no,
                'name' => 'Tidak ada data'
            ];
            $no++;
        }
    }

    return $data;
}




function getGpononu2() {

    // =============================
    // BACA FILE onu_index_map.txt
    // =============================
    if (!file_exists('onu_index_map.txt')) {
        return ['error' => 'onu_index_map.txt tidak ditemukan'];
    }

    $json = json_decode(file_get_contents('onu_index_map.txt'), true);
    if (!is_array($json)) {
        return ['error' => 'Format onu_index_map.txt salah'];
    }

    // =============================
    // FILTER INDEX DARI redamantinggi.txt
    // =============================
    $targetIndex = [];
    if (file_exists('redamantinggi.txt')) {
        $laser = json_decode(file_get_contents('redamantinggi.txt'), true);
        if (is_array($laser)) {
            $targetIndex = array_flip(array_keys($laser));
        }
    }

    $data = [];
    $no = 1;

    foreach ($json as $onuIndex => $info) {

        // jika index tidak ada di redamantinggi.txt, skip
        if (!isset($targetIndex[$onuIndex])) {
            continue;
        }

        if (!isset($info['interface'])) {
            continue;
        }

        $data[$onuIndex] = [
            'no'    => $no++,
            'nilai' => $info['interface'] // gpon-onu_1/x/x:x
        ];
    }

    return $data;
}





function getSn2() {
    global $ip, $port, $community;

    // =============================
    // BACA INDEX DARI redamantinggi.txt
    // =============================
    if (!file_exists('redamantinggi.txt')) {
        return ['error' => 'redamantinggi.txt tidak ditemukan'];
    }

    $laserJson = json_decode(file_get_contents('redamantinggi.txt'), true);
    if (!is_array($laserJson)) {
        return ['error' => 'Format redamantinggi.txt salah'];
    }

    // daftar index dari redamantinggi.txt
    $targetIndex = array_flip(array_keys($laserJson));

    // =============================
    // INIT SNMP
    // =============================
    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    // OID SERIAL NUMBER ONU
    $BASE_OID = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.18';

    $data = [];
    $no = 1;

    try {
        // =============================
        // WALK BASE OID
        // =============================
        $walk = $snmp->walk($BASE_OID);

        while ($walk->hasOids()) {
            $oidValue = $walk->next();
            $fullOid = (string)$oidValue->getOid();

            // pastikan masih subtree SN
            if (strpos($fullOid, $BASE_OID . '.') !== 0) {
                continue;
            }

            // ambil index baseindex.onuid
            $index = substr($fullOid, strlen($BASE_OID) + 1);

            // hanya index yang ada di redamantinggi.txt
            if (!isset($targetIndex[$index])) {
                continue;
            }

            $valObj = $oidValue->getValue();

            // ambil STRING SN dari FreeDSx
            $sn = is_object($valObj) && method_exists($valObj, 'getValue')
                ? (string)$valObj->getValue()
                : (string)$valObj;

            // buang prefix angka + koma (misal: "8,48575443")
            $sn = preg_replace('/^\d+,/', '', trim($sn));

            $data[$index] = [
                'no' => $no,
                'nilai' => $sn   // samakan key 'nilai' agar konsisten dengan bot
            ];

            $no++;
        }

    } catch (\Exception $e) {
        return ['error' => 'SNMP error: ' . $e->getMessage()];
    }

    // =============================
    // INDEX YANG TIDAK KETEMU
    // =============================
    foreach ($targetIndex as $idx => $v) {
        if (!isset($data[$idx])) {
            $data[$idx] = [
                'no' => $no,
                'nilai' => 'Tidak ada data'
            ];
            $no++;
        }
    }

    return $data;
}







?>