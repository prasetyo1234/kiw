<?php
session_start();
require 'koneksi.php';

// ========================
// Fungsi Tambah Tiket
// ========================
if (isset($_POST['title']) && isset($_POST['description']) && !isset($_POST['id']) && !isset($_POST['iddelete'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO tickets (title, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $description);

    if ($stmt->execute()) {
        echo "success_add";
    } else {
        echo "error_add";
    }

    $stmt->close();
    exit;
}

// ========================
// Fungsi Update Tiket
// ========================
if (isset($_POST['id']) && isset($_POST['title']) && isset($_POST['description'])) {
    $id = intval($_POST['id']);
    $title = $_POST['title'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE tickets SET title = ?, description = ? WHERE id = ?");
    $stmt->bind_param("ssi", $title, $description, $id);

    if ($stmt->execute()) {
        echo "success_update";
    } else {
        echo "error_update";
    }

    $stmt->close();
    exit;
}

// ========================
// Fungsi Hapus Tiket
// ========================
if (isset($_POST['iddelete'])) {
    $iddelete = intval($_POST['iddelete']);

    $stmt = $conn->prepare("DELETE FROM tickets WHERE id = ?");
    $stmt->bind_param("i", $iddelete);

    if ($stmt->execute()) {
        echo "success_delete";
    } else {
        echo "error_delete";
    }

    $stmt->close();
    exit;
}

// ========================
// Fungsi Ambil Daftar Tiket
// ========================
$result = $conn->query("SELECT id, title, description, created_at FROM tickets ORDER BY id DESC");

if ($result && $result->num_rows > 0) {
    echo '<ul class="list-group">';
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $title = !empty($row['title']) ? $row['title'] : '[Judul Kosong]';
        $description = !empty($row['description']) ? $row['description'] : '[Deskripsi Kosong]';
        $created_at = $row['created_at'];

        echo '<li class="list-group-item d-flex justify-content-between align-items-start">';
        echo '<div>';
        echo $no . '. Judul: ' . htmlspecialchars($title) . '<br>';
        echo 'Deskripsi: ' . htmlspecialchars($description) . '<br>';
        echo '<small class="text-muted">Dibuat: ' . $created_at . '</small>';
        echo '</div>';

        echo '<div class="btn-group btn-group-sm ml-2" role="group">';
        echo '<button class="btn btn-primary editTicketBtn" 
                    data-id="' . $id . '" 
                    data-title="' . htmlspecialchars($title) . '" 
                    data-description="' . htmlspecialchars($description) . '">
                    Edit
              </button>';
        echo '<button class="btn btn-danger deleteTicketBtn" data-id="' . $id . '">Hapus</button>';
        echo '</div>';

        echo '</li>';
        $no++;
    }
    echo '</ul>';
} else {
    echo '<p>Tidak ada tiket gangguan.</p>';
}

$conn->close();
?>
