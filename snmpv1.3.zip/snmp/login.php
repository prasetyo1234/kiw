<?php 
include 'koneksi.php'; 
session_start();

if (isset($_POST['submit'])) { 
  $username = $_POST['username']; 
  $password = $_POST['password']; 
  
  $query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
  $row = mysqli_fetch_assoc($query);

  if ($row) { 
    if ($password == $row['password']) { 
      $_SESSION['username'] = $row['username'];
      header("Location: index.php"); 
    } else { 
      echo "<script>alert('Password salah');</script>";
    } 
  } else { 
    echo "<script>alert('Username tidak ditemukan');</script>";
  } 
} 
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title></title>
    <!-- TABLE STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


<div class="container" style="margin-top: 180px;">
  <div class="content">

  <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="login-form card p-4 text-white" style="background-color: #2f3a50;">
          <h2 class="text-center">Login</h2>
          <form method="post">
            <div class="form-group">
              <label>Username</label>
              <input type="text" name="username" class="form-control bg-dark text-white" placeholder="Username">
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" name="password" class="form-control bg-dark text-white" placeholder="Password">
            </div>
            <button type="submit" name="submit" class="btn btn-primary btn-block" style="background-color: #7e3af2;">Login</button>
          </form>
        </div>
      </div>
    </div>

</div>
</div>

<div class="footer">
  <!-- konten footer -->
  <p>&copy; 2025 Muhammad Ilham | Pancor Sanggeng. All rights reserved.</p>
  <span class="version">v1.2</span>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>