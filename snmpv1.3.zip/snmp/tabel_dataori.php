<?php
if (!isset($_SESSION)) session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require 'snmpori.php';
$board     = getBoard();
$name     = getName();
$des      = getDes();
$gpononu  = getGpononu();
$sn       = getSn();
$state    = getState();
$laser    = getLaser();

?>


<!-- STATUS -->
<div class="status2">
    <div class="status-container">
        <span class="status-item">Total <?= $state['total']['all']; ?></span>
        <span class="status-item">Working <?= $state['total']['working']; ?><span class="animate-pulse working"></span></span>
        <span class="status-item">Dyinggasp <?= $state['total']['dyinggasp']; ?><span class="animate-pulse dyinggasp"></span></span>
        <span class="status-item">LOS <?= $state['total']['los']; ?><span class="animate-pulse los"></span></span>
        <span class="status-item">Offline <?= $state['total']['offline']; ?><span class="animate-pulse offline"></span></span>
    </div>
</div>

<!-- SEARCH -->
<div class="search-container">
    <span class="search-label">Search:</span>
    <div class="search-input-container">
        <input type="search" id="searchInput" class="search-input">
        <span class="clear-search" id="clearSearch">&times;</span>
    </div>
</div>

<div class="table-responsive bg-dark table-scroll">
<table id="tableData" class="table table-hover text-nowrap">
    <thead class="table-header">
        <tr>
            <th>NO</th>
            <th>NAME</th>
            <th>SLOT ONU</th>
            <th>SERIAL NUMBER</th>
            <th>STATE</th>
            <th>LASER</th>
            <th>ACTION</th>
        </tr>
    </thead>

    <tbody>
    <?php
    $max = max(count($name), count($gpononu), count($sn), count($state), count($laser));
    for ($i = 0; $i < $max; $i++) {
        if (!isset($name[$i]['nilai'])) continue;
    ?>
        <tr>
        <td><?php echo ($i + 1); ?></td>
                <td class="name-value"><?php echo $name[$i]['nilai'] ?? ''; ?></td>
                <td><?php echo $gpononu[$i]['nilai'] ?? ''; ?></td>
                <td><?php echo $sn[$i]['nilai'] ?? ''; ?></td>
                <td class="state-value"><?php echo $state[$i]['status'] ?? ''; ?></td>
                <td>
                    <span class="laser-value" onclick="reloadLaserValue(this, '<?php echo $laser[$i]['onu_id']; ?>', '<?php echo $state[$i]['onu_id']; ?>', '<?php echo $name[$i]['onu_id']; ?>')">
                        <span class="laser-value-text"><?php echo $laser[$i]['nilai'] ?? ''; ?></span>
                    </span>
                </td>

<!-- dropdown -->
<td>
    <div class="d-flex align-items-center gap-2">

        <!-- DROPDOWN TELNET -->
        <div class="dropdown">
            <button class="btn btn-sm dropdown-toggle-no-caret btn-link"
                    data-toggle="dropdown">
                <i class="fa fa-terminal text-secondary"></i>
            </button>

            <ul class="dropdown-menu dropdown-menu-dark">
                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="vlanRemoteModal(
                            '<?= $gpononu[$i]['nilai']; ?>',
                            '<?= $name[$i]['nilai']; ?>'
                        )">
                        <i class="fa fa-bolt mr-2"></i>
                        vlan setting
                    </button>
                </li>

                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="openRemoteModal(
                            '<?= $gpononu[$i]['nilai']; ?>',
                            '<?= $name[$i]['nilai']; ?>'
                        )">
                        <i class="fa fa-wifi mr-2"></i>
                        ssid setting
                    </button>
                </li>
                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="pppoeRemoteModal(
                            '<?= $gpononu[$i]['nilai']; ?>',
                            '<?= $name[$i]['nilai']; ?>'
                        )">
                        <i class="fa fa-users mr-2"></i>
                        pppoe setting
                    </button>
                </li>
                
            </ul>
        </div>

        <!-- DROPDOWN SNMP -->
        <div class="dropdown">
            <button class="btn btn-sm dropdown-toggle-no-caret btn-link"
                    data-toggle="dropdown">
                <i class="fa fa-cog text-secondary"></i>
            </button>

            <ul class="dropdown-menu dropdown-menu-dark">
                <li>
                    <button class="btn btn-sm btn-edit text-white w-100"
                        data-idname="<?= $name[$i]['onu_id']; ?>"
                        data-iddes="<?= $des[$i]['onu_id']; ?>"
                        data-name="<?= htmlspecialchars($name[$i]['nilai']); ?>"
                        data-des="<?= htmlspecialchars($des[$i]['nilai']); ?>">
                        <i class="fa fa-edit mr-2"></i> Edit
                    </button>
                </li>

                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="rebootOnu('<?= $name[$i]['onu_id']; ?>','<?= $name[$i]['nilai']; ?>')">
                        <i class="fa fa-refresh mr-2"></i> Reboot
                    </button>
                </li>

                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="resetOnu('<?= $name[$i]['onu_id']; ?>','<?= $name[$i]['nilai']; ?>')">
                        <i class="fa fa-undo mr-2"></i> Reset
                    </button>
                </li>

                <li>
                    <button class="btn btn-sm text-white w-100"
                        onclick="deleteOnu('<?= $name[$i]['onu_id']; ?>','<?= $name[$i]['nilai']; ?>')">
                        <i class="fa fa-trash mr-2"></i> Hapus
                    </button>
                </li>
            </ul>
        </div>

    </div>
</td>
<!-- dropdown -->

        </tr>
    <?php } ?>
    </tbody>
</table>
</div>

<!-- ================= snmp modal ================= -->
<div class="modal fade" id="editModal" tabindex="-1">
<div class="modal-dialog">
<div class="modal-content">

    <div class="modal-header">
        <h5 class="modal-title">Update ONU</h5>
        <button type="button" class="close" data-dismiss="modal">
            <span>&times;</span>
        </button>
    </div>

    <form id="editForm" method="post">
        <div class="modal-body text-dark">

            <input type="hidden" name="idname" id="idname">
            <input type="hidden" name="iddes" id="iddes">

            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="valuename" id="valuename" required>
            </div>

            <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control" name="valuedes" id="valuedes" required>
            </div>

        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-info">
                <i class="fa fa-save"></i> Simpan
            </button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">
                Close
            </button>
        </div>
    </form>

</div>
</div>
</div>

<!-- telnet modal -->
<div class="modal fade" id="remoteModal" tabindex="-1">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content text-dark">

      <div class="modal-header">
        <h5 class="modal-title">
          <i class="fa fa-terminal"></i> Setting ONU
        </h5>
        <button type="button" class="close" data-dismiss="modal">
          <span>&times;</span>
        </button>
      </div>

      <div class="modal-body">

        <!-- Info ONU -->
        <div id="remoteInfo" class="small mb-2 text-muted text-center"></div>

        <!-- ================= STATUS REMOTE ================= -->
        <div class="text-center mb-3">
          <span class="badge badge-secondary px-3 py-2" id="remoteStatusText">
            Loading...
          </span>
        </div>

        <!-- Tambahkan ini untuk IP -->
        <div class="text-center mb-3">
            <small id="remoteIpText" class="text-muted">IP: -</small>
        </div>

        <!-- MAC (DI BAWAH IP) -->
        <div class="text-center mb-3">
            <small id="remoteMacText" class="text-muted">MAC: -</small>
        </div>


        <!-- ================= SSID Setting ================= -->
        <div class="form-group">
          <label class="small font-weight-bold">
            <i class="fa fa-wifi"></i> SSID Setting
          </label>

          <div class="input-group input-group-sm mb-1">
            <input type="text"
                   id="ssidSetting"
                   class="form-control"
                   placeholder="Nama SSID">

            <div class="input-group-append d-flex">
              <!-- Select SSID -->
              <select id="ssidIndex" class="form-control form-control-sm">
                <option value="1">SSID1</option>
                <option value="2">SSID2</option>
                <option value="3">SSID3</option>
                <option value="4">SSID4</option>
                <option value="5">SSID5</option>
                <option value="6">SSID6</option>
                <option value="7">SSID7</option>
                <option value="8">SSID8</option>
              </select>

              <!-- Select Enable/Disable (lebih kecil) -->
              <select id="ssidState" class="form-control form-control-sm ml-1" style="width:80px;">
                <option value="enable">Enable</option>
                <option value="disable">Disable</option>
              </select>
            </div>
          </div>

          <small class="text-muted">
            Enable = Unlock SSID | Disable = Lock SSID
          </small>
        </div>

        <!-- ================= WPA2 Password ================= -->
        <div class="form-group">
          <label class="small font-weight-bold">
            <i class="fa fa-lock"></i> Password Setting
          </label>

          <div class="input-group input-group-sm">
            <input type="text"
                   id="passWpa2Setting"
                   class="form-control"
                   placeholder="kosongin kalo make hotspot">
          </div>
        </div>

        <hr>

        <!-- ================= Remote ON/OFF ================= -->
        <div class="form-group">
          <label class="small font-weight-bold">
            <i class="fa fa-link"></i> Remote State
          </label>

          <select id="remoteState" class="form-control form-control-sm">
            <option value="on">Remote ON</option>
            <option value="off">Remote OFF</option>
          </select>
        </div>

        <!-- ================= Submit ================= -->
        <button id="btnSubmitRemote"
                class="btn btn-primary btn-block mt-3" style="background-color: #7e3af2;">
          <i class="fa fa-terminal"></i> Submit
        </button>

      </div>

    </div>
  </div>
</div>





<!-- ================= SCRIPT ================= -->
<script>
//search
$(document).ready(function() {
    $('#searchInput').on('input', function() {
        var value = $(this).val().toLowerCase();
        $('table tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });

        if ($(this).val() !== '') {
            $('#clearSearch').show();
        } else {
            $('#clearSearch').hide();
        }
    });

    $('#clearSearch').on('click', function() {
        $('#searchInput').val('');
        $('table tbody tr').show();
        $(this).hide();
    });
});
//asc
$('th').each(function() {
    $(this).html($(this).html() + ' <span class="caret">&#8597;</span>');
    $(this).data('sort', 'asc');
});
$('th').on('click', function() {
    var index = $(this).index();
    var table = $(this).closest('table');
    var rows = table.find('tbody tr').get();
    var sort = $(this).data('sort');
    rows.sort(function(a, b) {
        var A = $(a).children('td').eq(index).text().toUpperCase();
        var B = $(b).children('td').eq(index).text().toUpperCase();
        if (sort === 'asc') {
            if (A < B) {
                return -1;
            }
            if (A > B) {
                return 1;
            }
            return 0;
        } else {
            if (A < B) {
                return 1;
            }
            if (A > B) {
                return -1;
            }
            return 0;
        }
    });
    $.each(rows, function(index, row) {
        table.children('tbody').append(row);
    });
    var caret = $(this).find('.caret');
    if (caret.text() === '↓') {
        caret.text('↑');
        $(this).data('sort', 'asc');
    } else {
        caret.text('↓');
        $(this).data('sort', 'desc');
    }
});



</script>
