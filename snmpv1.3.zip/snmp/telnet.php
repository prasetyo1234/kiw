<?php
include 'koneksi.php';
$timeout = 10;

$fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);

if (!$fp) {
    echo "Koneksi gagal";
    exit;
}

//aktivasi
if (isset($_POST['submit'])) {
    $ONUTYPE = $_POST['onutype'];
    $PROFILETYPE = $_POST['profiletype'];
    $NAME = $_POST['name'];
    $DESKRIPSI = $_POST['deskripsi'];
    $VLANHOT = $_POST['vlanhot'];
    $SSIDHOT = $_POST['ssidhot'];
    $SSIDPPP = $_POST['ssidppp'];
    $PASS2PPP = $_POST['pass2ppp'];
    $VLANPPP = $_POST['vlanppp'];
    $USERPPP = $_POST['userppp'];
    $PASSPPP = $_POST['passppp'];
    $PROFILEVLAN = $_POST['profilevlan'];
    $VLANSTA = $_POST['vlansta'];
    $IPSTA = $_POST['ipsta'];
    $PROFILEIP = $_POST['profileip'];
    $PROFILEVLANS = $_POST['profilevlans'];
    $port_selected = isset($_POST['port']) ? $_POST['port'] : '';

    $part = explode(',', $_POST['regisonu']);
    $GPONOLT = $part[0];
    $SN = $part[1];
    $GPON = $part[2];
    $ONU = $part[3];

    include 'koneksi.php';
    $timeout = 10;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);
    if (!$fp) {
        echo "Koneksi gagal";
        exit;
    }

    // Baca respons login
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);
    if (strpos($output, "Password:") !== false) {
        // Jika diminta password, masukkan password
        fwrite($fp, "password\r\n");
        $output = fread($fp, 1024);
    }
    fwrite($fp, "conf t\r\n");
    $output = fread($fp, 1024);

    // Jalankan perintah konfigurasi
    $commands = array();
    $commands[] = "interface $GPONOLT";
    $commands[] = "onu $ONU type $ONUTYPE sn $SN";
    $commands[] = "exit";

    $commands[] = "interface $GPON:$ONU";
    if (!empty($NAME)) {
        $commands[] = "name $NAME";
    }
    if (!empty($DESKRIPSI)) {
        $commands[] = "description $DESKRIPSI";
    }
    $commands[] = "tcont 1 profile $PROFILETYPE";
    $commands[] = "gemport 1 tcont 1";
    if (!empty($VLANHOT)) {
        $commands[] = "service-port 1 vport 1 user-vlan $VLANHOT vlan $VLANHOT";
    }
    if (!empty($VLANPPP)) {
        $commands[] = "service-port 2 vport 1 user-vlan $VLANPPP vlan $VLANPPP";
    }
    if (!empty($VLANSTA)) {
        $commands[] = "service-port 3 vport 1 user-vlan $VLANSTA vlan $VLANSTA";
    }
    $commands[] = "service-port 10 vport 1 user-vlan 100 vlan 100";
    $commands[] = "exit";

    $commands[] = "pon-onu-mng $GPON:$ONU";
        if (!empty($VLANHOT)) {
            $commands[] = "service hot gemport 1 vlan $VLANHOT";
        }
        if (!empty($VLANPPP)) {
            $commands[] = "service ppp gemport 1 vlan $VLANPPP";
        }
        if (!empty($VLANSTA)) {
            $commands[] = "service sta gemport 1 vlan $VLANSTA";
        }
    $commands[] = "service acs gemport 1 vlan 100";

    if (!empty($VLANHOT)) {
        $commands[] = "vlan port veip_1 mode tag vlan $VLANHOT";
        if (!empty($port_selected)) {
            foreach ($port_selected as $port) {
                $commands[] = "vlan port $port mode tag vlan $VLANHOT";
            }
        }
    }
    if (!empty($VLANPPP)) {
        $commands[] = "vlan port veip_1 mode tag vlan $VLANPPP";
    }
    if (!empty($VLANHOT)) {
        if (!empty($SSIDHOT)) {
            $commands[] = "interface wifi wifi_0/1 state unlock";
            $commands[] = "interface wifi wifi_0/5 state unlock";
            $commands[] = "ssid ctrl wifi_0/1 name $SSIDHOT";
            $commands[] = "ssid ctrl wifi_0/5 name $SSIDHOT";
            $commands[] = "ssid auth wep wifi_0/1 open-system";
            $commands[] = "ssid auth wep wifi_0/5 open-system";
        }
    }
    if (!empty($VLANPPP)) {
        if (!empty($SSIDPPP)) {
            $commands[] = "interface wifi wifi_0/2 state unlock";
            $commands[] = "interface wifi wifi_0/6 state unlock";
            $commands[] = "ssid ctrl wifi_0/2 name $SSIDPPP";
            $commands[] = "ssid ctrl wifi_0/6 name $SSIDPPP";
            $commands[] = "ssid auth wpa wifi_0/2 wpa2-psk key $PASS2PPP";
            $commands[] = "ssid auth wpa wifi_0/6 wpa2-psk key $PASS2PPP";
        }
    }
    if (!empty($VLANPPP)) {
        if (!empty($USERPPP) && !empty($PASSPPP)) {
            $commands[] = "wan-ip 1 mode pppoe username $USERPPP password $PASSPPP vlan-profile $PROFILEVLAN host 1";
        }
    }
    if (!empty($VLANSTA)) {
        if (!empty($IPSTA)) {
            $commands[] = "wan-ip 2 mode static ip-profile $PROFILEIP ip-address 1.5.6.$IPSTA mask 255.255.255.0 vlan-profile $PROFILEVLANS host 2";
        }
    }
    $commands[] = "end";
    $commands[] = "wr";

    foreach ($commands as $command) {
        fwrite($fp, $command . "\r\n");
        sleep(1);
        $output = fread($fp, 1024);
        if (strpos($output, "Error") !== false) {
        echo "$command -------- $output";
        exit;
    }
}

//fclose($fp);
}





//showtelnet
// ==============================
// SHOW STATUS REMOTE (READ ONLY) + IP
// ==============================
if (isset($_POST['showidremote'])) {

    header('Content-Type: application/json');

    $gponOnu = $_POST['showidremote'];

    // ================= LOGIN TELNET =================
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 2048);

    // ================= ENABLE =================
    fwrite($fp, "enable\r\n");
    usleep(300000);
    $output = fread($fp, 2048);

    // ================= SHOW ONU RUNNING CONFIG =================
    fwrite($fp, "show onu running config " . $gponOnu . "\r\n");
    usleep(600000);
    $onuOutput = fread($fp, 8192);

    // ================= SHOW MAC ADDRESS =================
    fwrite($fp, "show mac gpon onu " . $gponOnu . "\r\n");
    usleep(600000);
    $macOutput = fread($fp, 8192);

    // ================= PARSING TOTAL MAC =================
    $totalMac = 0;
    if (preg_match('/Total mac address\s*:\s*(\d+)/i', $macOutput, $m)) {
        $totalMac = (int)$m[1];
    }

    // ================= PARSING MAC LIST =================
    $macList = [];
    if (preg_match_all('/([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4})/i', $macOutput, $m)) {
        $macList = array_unique($m[1]);
    }

    // ================= PARSING STATUS =================
    $status = (
        strpos($onuOutput, 'security-mgmt 212') !== false &&
        strpos($onuOutput, 'state enable') !== false
    ) ? 'on' : 'off';

    // ================= PARSING IP =================
    $ipAddresses = [];
    if (preg_match_all('/ip-address\s+([\d\.]+)/', $onuOutput, $matches)) {
        $ipAddresses = $matches[1];
    }

    // ================= RESPONSE JSON =================
    echo json_encode([
        'total_mac' => $totalMac,
        'macs'      => $macList,
        'status'    => $status,
        'ip'        => $ipAddresses
    ]);

    exit;
}





// ================= TAMPILKAN SEMUA SSID + PASSWORD WPA2/WEP =================
if (isset($_POST['showallssid'])) {

    header('Content-Type: application/json');

    $gponOnu = $_POST['showallssid'];

    // ================= LOGIN TELNET =================
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 2048);

    // ================= ENABLE =================
    fwrite($fp, "enable\r\n");
    usleep(300000);
    $output = fread($fp, 2048);

    // ================= SHOW RUNNING CONFIG =================
    fwrite($fp, "show onu running config " . $gponOnu . "\r\n");
    usleep(600000);
    $output = fread($fp, 8192);

    // ================= PARSING SSID 1-8 =================
    $ssids = [];

    for ($i = 1; $i <= 8; $i++) {

        $ssidName = null;
        $ssidAuth = ''; // default kosong (open-system tidak dikirim)

        // ================= AMBIL NAMA SSID =================
        if (preg_match("/ssid ctrl wifi_0\/$i name (.+)/", $output, $matches)) {
            $ssidName = trim($matches[1]);
        }

        // ================= AMBIL AUTH WPA2 / WEP =================
        if (preg_match("/ssid auth (wep|wpa) wifi_0\/$i (.+)/", $output, $matches)) {

            $type = $matches[1];       // wep | wpa
            $raw  = trim($matches[2]); // open-system | wpa2-psk key xxxx

            if ($type === 'wpa') {

                // Ambil password WPA2
                if (preg_match("/key\s+(.+)/", $raw, $m)) {
                    $ssidAuth = trim($m[1]);
                }

            } elseif ($type === 'wep') {

                // JIKA open-system → kosongkan
                if ($raw !== 'open-system') {
                    $ssidAuth = $raw;
                }
            }
        }

        // ================= SIMPAN DATA =================
        $ssids[$i] = [
            'index' => $i,
            'name'  => $ssidName,
            'auth'  => $ssidAuth
        ];
    }

    // ================= RESPONSE JSON =================
    echo json_encode([
        'ssids' => $ssids
    ]);

    exit;
}









// ================= SET_SSID & PASSWORD =================
if (isset($_POST['setssidpass'])) {

    $gponOnu   = $_POST['setssidpass'];
    $ssid      = isset($_POST['ssid']) ? trim($_POST['ssid']) : '';
    $pass      = isset($_POST['pass']) ? trim($_POST['pass']) : '';
    $ssidIndex = isset($_POST['ssidindex']) ? intval($_POST['ssidindex']) : 1;
    $ssidState = isset($_POST['ssidstate']) ? $_POST['ssidstate'] : 'enable'; // dari select JS

    // Mapping linear SSID1-8 ke interface wifi
    $wifi_map = [
        1 => 'wifi_0/1',
        2 => 'wifi_0/2',
        3 => 'wifi_0/3',
        4 => 'wifi_0/4',
        5 => 'wifi_0/5',
        6 => 'wifi_0/6',
        7 => 'wifi_0/7',
        8 => 'wifi_0/8'
    ];
    $wifiIf = $wifi_map[$ssidIndex] ?? 'wifi_0/1';

    // Tentukan state interface
    $stateWifi = ($ssidState === 'enable') ? 'unlock' : 'lock';

    // ================= LOGIN TELNET =================
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);

    // ================= KIRIM PERINTAH =================
    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "config t\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "pon-onu-mng " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);

    // ================= SET STATE WIFI =================
    // Perintah lock/unlock harus selalu dikirim sesuai ssidState
    fwrite($fp, "interface wifi $wifiIf state $stateWifi\r\n");
    $output = fread($fp, 1024);

    // ================= SET SSID NAME =================
    if ($ssid !== '') {
        fwrite($fp, "ssid ctrl $wifiIf name $ssid\r\n");
        $output = fread($fp, 1024);
    }

    // ================= SET PASSWORD =================
    if ($pass !== '') {
        // ===== JIKA ADA PASSWORD → WPA2-PSK =====
        fwrite($fp, "ssid auth wpa $wifiIf wpa2-psk key $pass\r\n");
        $output = fread($fp, 1024);
    
    } else {
        // ===== JIKA KOSONG → WEP OPEN SYSTEM =====
        fwrite($fp, "ssid auth wep $wifiIf open-system\r\n");
        $output = fread($fp, 1024);
    }

    // ================= AKHIR =================
    fwrite($fp, "end\r\n");
    $output = fread($fp, 1024);

    if (strpos($output, "error") === false) {
        echo "SET Onu Success";
    } else {
        echo "Gagal";
    }
}












//remoteon
if (isset($_POST['idremoteon'])) {
    $gponOnu = $_POST['idremoteon'];

    // Baca respons login
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);

    // Kirim perintah
    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "config t\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "interface " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "service-port 10 vport 1 user-vlan 100 vlan 100\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "exit\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "pon-onu-mng " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "service acs gemport 1 vlan 100\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "exit\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "pon-onu-mng " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "security-mgmt 212 state enable mode forward protocol web\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "end\r\n");
    $output = fread($fp, 1024);
    

    if (strpos($output, "error") === false) {
        echo "Berhasil";
    } else {
        echo "Gagal";
    }
}

//remoteoff
if (isset($_POST['idremoteoff'])) {
    $gponOnu = $_POST['idremoteoff'];

    // Baca respons login
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);

    // Kirim perintah
    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "config t\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "interface " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "no service-port 10\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "exit\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "pon-onu-mng " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "no service acs\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "exit\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "pon-onu-mng " . $gponOnu . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "no security-mgmt 212\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, "end\r\n");
    $output = fread($fp, 1024);
    

    if (strpos($output, "error") === false) {
        echo "Berhasil";
    } else {
        echo "Gagal";
    }
}

fclose($fp);
?>