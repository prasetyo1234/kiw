<?php
require_once __DIR__.'/src/PHPTelebot.php';
include 'koneksi.php';
require 'snmpbot.php';
include 'snmpbotone.php';
include 'snmpset.php';
$bot = new PHPTelebot(''. $token .'', ''. $yourid .'');



$bot->cmd('/start', function () use ($groupId, $yourid) {
    $message = Bot::message();
    $userid = $message['from']['id'];
    $firstname = $message['from']['first_name'];
    $lastname = $message['from']['last_name'];
    $chatid = $message['chat']['id'];

    if (($chatid == $groupId) || ($userid == $yourid)) {
        include 'koneksi.php';
        $state = getState2();
        include 'koneksi.php';
        $idup = $state['total']['working'];
        $mate = $state['total']['dyinggasp'];
        $ptok = $state['total']['los'];
        $offline = $state['total']['offline'];
        $all = $state['total']['all'];
        $text = " Hallo $firstname $lastname!..\nAku Bot OLTZTE!..🔥🔥🔥\nLaguk anti, begak sue loading ne!..\n\nList Perintah {/ceklaser /setname /reboot /reset /delete /setssid}\n\n\n";
        $text .= "Total : $all\n";
        $text .= "Working : $idup\n";
        $text .= "DyingGasp : $mate\n";
        $text .= "LOS : $ptok\n";
        $text .= "Offline : $offline\n";
        $options = [
            'chat_id' => $chatid,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔌 DyingGasp', 'callback_data' => 'cekdyinggasp'],
                        ['text' => '🚨 LOS', 'callback_data' => 'ceklos'],
                        ['text' => '💀 Offline', 'callback_data' => 'cekoffline'],
                    ],
                    [
                        ['text' => '📉 Redamantinggi', 'callback_data' => 'cekredamantinggi'],
                    ],
                ]
            ]),
            'parse_mode' => 'html'
        ];
        return Bot::sendMessage($text, $options);
    } else {
        $text = "Maaf..! Aksess Hanya untuk Administator😱";
        $options = [
            'chat_id' => $chatid,
            'message_id' => (int) $message['message']['message_id'],
            'text' => $text,
        ];
        return Bot::sendMessage($text, $options);
    }
});

  $bot->cmd('*', function () {
    $message = Bot::message();
    $userid = $message['from']['id'];
    $firstname = $message['from']['first_name'];
    $lastname = $message['from']['last_name'];
    include 'koneksi.php';
  
    if ($userid == $yourid) { 
      $state = getState2();
      include 'koneksi.php';
      $idup = $state['total']['working'];
      $mate = $state['total']['dyinggasp'];
      $ptok = $state['total']['los'];
      $offline = $state['total']['offline'];
      $all = $state['total']['all'];
      $text = " Hallo $firstname $lastname!..\nAku Bot OLTZTE!..🔥🔥🔥\nLaguk anti, begak sue loading ne!..\n\nList Perintah {/ceklaser /setname /reboot /reset /delete /setssid}\n\n\n";
      $text .= "Total : $all\n";
      $text .= "Working : $idup\n";
      $text .= "DyingGasp : $mate\n";
      $text .= "LOS : $ptok\n";
      $text .= "Offline : $offline\n";
      $options = [
        'chat_id' => $userid,
        'message_id' => (int) $message['message']['message_id'],
        'text' => $text,
        'reply_markup' => json_encode([
           'inline_keyboard' => [
            [
                ['text' => '🔌 DyingGasp', 'callback_data' => 'cekdyinggasp'],
                ['text' => '🚨 LOS', 'callback_data' => 'ceklos'],
                ['text' => '💀 Offline', 'callback_data' => 'cekoffline'],
            ],
            [
                ['text' => '📉 Redamantinggi', 'callback_data' => 'cekredamantinggi'],
            ],
              ]]),
        'parse_mode' => 'html'
    
     ];
      
    }else {
  
    $text = "Maaf..! Aksess Hanya untuk Administator😱";
  }
    return Bot::sendMessage($text, $options);
  });

  $bot->cmd('/ceklaser', function ($txpower) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];
    include 'koneksi.php';

    if (empty($txpower)) {
        $pesan = "ketik {/ceklaser spasi id nama_pelanggan}";
    } else {
        if ($chatid == $groupId || $userid == $yourid) {

            // PANGGIL getOne() LANGSUNG
            $result = getOne($txpower);

            if ($result['status'] === 'success') {
                $data = $result['data']; // ambil langsung dari array return getOne()

                $pesan = "Nama : " . ($data['name'] ?? '-') . "\n";
                $pesan .= "GponOnu : " . ($data['interface'] ?? '-') . "\n";
                $pesan .= "SN : " . ($data['sn'] ?? '-') . "\n";
                $pesan .= "State : " . ($data['state'] ?? '-') . "\n";
                $pesan .= "Laser : " . ($data['laser'] ?? 'N/A') . " dBm\n";

            } else {
                $pesan = $result['message'] ?? "ID atau Nama pelanggan tidak ditemukan ❌";
            }

        } else {
            $pesan = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    }

    return Bot::sendMessage($pesan);
});

// /setname
$bot->cmd('/setname', function ($params) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];

    if ($chatid != $groupId && $userid != $yourid) {
        return Bot::sendMessage("Maaf..! Akses hanya untuk Administrator 😱");
    }

    $args = explode(' ', $params, 2); // batasi split 2 bagian
    if (count($args) < 2) {
        return Bot::sendMessage("Format salah! Ketik: /setname <Nama_Lama> <Nama_Baru>");
    }

    $nama_lama = $args[0];
    $nama_baru = $args[1];

    // Baca file onu_index_map.txt
    $json_data = file_get_contents(__DIR__ . '/onu_index_map.txt');
    $onu_map = json_decode($json_data, true);

    $baseindex = null;
    foreach ($onu_map as $index => $data) {
        if (isset($data['name']) && $data['name'] === $nama_lama) {
            $baseindex = $index;
            break;
        }
    }

    if (!$baseindex) {
        return Bot::sendMessage("Nama lama '$nama_lama' tidak ditemukan ❌");
    }

    // Buat OID lengkap
    $oid_prefix = "1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2";
    $oid_full = $oid_prefix . "." . $baseindex;

    // --- EKSEKUSI LANGSUNG SNMPSET.PHP ---
    $_POST['idname'] = $oid_full;
    $_POST['valuename'] = $nama_baru;

    ob_start(); // tangkap output
    include __DIR__ . '/snmpset.php'; // langsung tanpa folder snmp
    $response = ob_get_clean();

    return Bot::sendMessage($response);
});



// /reboot
$bot->cmd('/reboot', function ($params) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];

    if ($chatid != $groupId && $userid != $yourid) {
        return Bot::sendMessage("Maaf..! Akses hanya untuk Administrator 😱");
    }

    $nama_onu = trim($params);
    if (empty($nama_onu)) {
        return Bot::sendMessage("Format salah! Ketik: /reboot <Nama_ONU>");
    }

    // Baca file base_onu_index.txt
    $json_file = 'onu_index_map.txt';
    $json_data = file_get_contents($json_file);
    $onu_map = json_decode($json_data, true);

    $baseindex = null;
    foreach ($onu_map as $index => $data) {
        if (isset($data['name']) && $data['name'] === $nama_onu) {
            $baseindex = $index;
            break;
        }
    }

    if (!$baseindex) {
        return Bot::sendMessage("Nama ONU '$nama_onu' tidak ditemukan ❌");
    }

    // Buat OID lengkap tanpa port
    $oid_prefix = "1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2";
    $oid_full = $oid_prefix . "." . $baseindex;

    // --- EKSEKUSI LANGSUNG SNMPSET.PHP TANPA URL ---
    $_POST['idreboot'] = $oid_full;
    $_POST['valuereboot'] = 1;

    ob_start(); // tangkap output snmpset.php
    include __DIR__ . '/snmpset.php'; // langsung tanpa folder snmp
    $response = ob_get_clean();

    return Bot::sendMessage($response);
});





// /reset
$bot->cmd('/reset', function ($params) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];

    if ($chatid != $groupId && $userid != $yourid) {
        return Bot::sendMessage("Maaf..! Akses hanya untuk Administrator 😱");
    }

    $nama_onu = trim($params);
    if (empty($nama_onu)) {
        return Bot::sendMessage("Format salah! Ketik: /reset <Nama_ONU>");
    }

    // Baca file onu_index_map.txt
    $json_file = 'onu_index_map.txt';
    if (!file_exists($json_file)) {
        return Bot::sendMessage("File $json_file tidak ditemukan ❌");
    }

    $json_data = file_get_contents($json_file);
    $onu_map = json_decode($json_data, true);
    if (!$onu_map) {
        return Bot::sendMessage("Gagal membaca data dari $json_file ❌");
    }

    $baseindex = null;
    foreach ($onu_map as $index => $data) {
        if (isset($data['name']) && $data['name'] === $nama_onu) {
            $baseindex = $index;
            break;
        }
    }

    if (!$baseindex) {
        return Bot::sendMessage("Nama ONU '$nama_onu' tidak ditemukan ❌");
    }

    // Buat OID lengkap tanpa port
    $oid_prefix = "1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2";
    $oid_full = $oid_prefix . "." . $baseindex;

    // --- EKSEKUSI LANGSUNG SNMPSET.PHP UNTUK RESET ---
    $_POST['idreset'] = $oid_full;
    $_POST['valuereset'] = 1;

    ob_start(); // tangkap output snmpset.php
    include __DIR__ . '/snmpset.php'; // langsung tanpa folder snmp
    $response = ob_get_clean();

    return Bot::sendMessage($response);
});






// /delete
$bot->cmd('/delete', function ($params) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];

    if ($chatid != $groupId && $userid != $yourid) {
        return Bot::sendMessage("Maaf..! Akses hanya untuk Administrator 😱");
    }

    $nama_onu = trim($params);
    if (empty($nama_onu)) {
        return Bot::sendMessage("Format salah! Ketik: /delete <Nama_ONU>");
    }

    // Baca file onu_index_map.txt
    $json_file = 'onu_index_map.txt';
    if (!file_exists($json_file)) {
        return Bot::sendMessage("File $json_file tidak ditemukan ❌");
    }

    $json_data = file_get_contents($json_file);
    $onu_map = json_decode($json_data, true);
    if (!$onu_map) {
        return Bot::sendMessage("Gagal membaca data dari $json_file ❌");
    }

    $baseindex = null;
    foreach ($onu_map as $index => $data) {
        if (isset($data['name']) && $data['name'] === $nama_onu) {
            $baseindex = $index;
            break;
        }
    }

    if (!$baseindex) {
        return Bot::sendMessage("Nama ONU '$nama_onu' tidak ditemukan ❌");
    }

    // Buat OID lengkap tanpa port
    $oid_prefix = "1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2";
    $oid_full = $oid_prefix . "." . $baseindex;

    // --- EKSEKUSI LANGSUNG SNMPSET.PHP UNTUK DELETE ---
    $_POST['iddelete'] = $oid_full;
    $_POST['valuedelete'] = 6;

    ob_start(); // tangkap output snmpset.php
    include __DIR__ . '/snmpset.php'; // langsung tanpa folder snmp
    $response = ob_get_clean();

    return Bot::sendMessage($response);
});





// /setssid
$bot->cmd('/setssid', function ($params) use ($groupId, $yourid) {
    $message = Bot::message();
    $userid  = $message['from']['id'];
    $chatid  = $message['chat']['id'];

    if ($chatid != $groupId && $userid != $yourid) {
        return Bot::sendMessage("Maaf..! Akses hanya untuk Administrator 😱");
    }

    $args = explode(' ', $params);

    // Minimal 5 parameter: Nama_ONU SSID PASSWORD|hotspot SSIDINDEX STATE
    if (count($args) < 5) {
        return Bot::sendMessage("Format salah! Ketik: /setssid <Nama_ONU> <SSID> <PASSWORD|hotspot> <SSIDINDEX> <STATE>");
    }

    $nama_onu  = trim($args[0]);
    $ssid      = trim($args[1]);
    $password  = trim($args[2]);
    $ssidIndex = intval($args[3]);
    $ssidState = strtolower(trim($args[4]));

    // Validasi input tidak boleh kosong
    if ($nama_onu === '' || $ssid === '' || $password === '' || $ssidIndex < 1 || $ssidIndex > 8 || !in_array($ssidState, ['enable', 'disable'])) {
        return Bot::sendMessage("Input tidak valid! Pastikan semua field terisi dengan benar.\nSSIDINDEX: 1-8\nSTATE: enable/disable\nPassword: tulis 'hotspot' untuk open-system");
    }

    // Jika user menulis 'hotspot', password dikosongkan → open-system
    if (strtolower($password) === 'hotspot') {
        $password = '';
    }

    // Baca file onu_index_map.txt
    $json_file = __DIR__ . '/onu_index_map.txt';
    if (!file_exists($json_file)) {
        return Bot::sendMessage("File $json_file tidak ditemukan ❌");
    }

    $json_data = file_get_contents($json_file);
    $onu_map = json_decode($json_data, true);

    $gponOnu = null;
    foreach ($onu_map as $data) {
        if (isset($data['name']) && $data['name'] === $nama_onu) {
            $gponOnu = $data['interface'] ?? null;
            break;
        }
    }

    if (!$gponOnu) {
        return Bot::sendMessage("Nama ONU '$nama_onu' tidak ditemukan ❌");
    }

    // --- EKSEKUSI TELNET.PHP LANGSUNG ---
    $_POST['setssidpass'] = $gponOnu;
    $_POST['ssid']        = $ssid;
    $_POST['pass']        = $password;
    $_POST['ssidindex']   = $ssidIndex;
    $_POST['ssidstate']   = $ssidState;

    ob_start();
    include __DIR__ . '/telnet.php';
    $response = ob_get_clean();

    return Bot::sendMessage($response);
});






$groupIdArray = array($groupId);
$bot->on('callback', function ($command) use ($groupIdArray, $yourid) {
    if ($command == 'status') {

        $update = Bot::message();     // semua update (message / callback)
        
        // --- Ambil chat_id ---
        if (isset($update['chat']['id'])) {
            $chatid = $update['chat']['id'];
        } elseif (isset($update['message']['chat']['id'])) {
            $chatid = $update['message']['chat']['id'];
        } else {
            $chatid = null;
        }
    
        // --- Ambil message_id (HARUS BENAR!) ---
        if (isset($update['message_id'])) {
            $message_id = $update['message_id'];
        } elseif (isset($update['message']['message_id'])) {
            $message_id = $update['message']['message_id'];
        } elseif (isset($update['callback_query']['message']['message_id'])) {
            $message_id = $update['callback_query']['message']['message_id'];
        } else {
            $message_id = null;
        }
    
        // --- Ambil user info ---
        $userid     = $update['from']['id'] ?? 0;
        $firstname  = $update['from']['first_name'] ?? '';
        $lastname   = $update['from']['last_name'] ?? '';
    
        include 'koneksi.php';
    
        // --- Cek akses admin ---
        if (($chatid == $groupId) || ($userid == $yourid)) {
    
            $state = getState2();
    
            $idup    = $state['total']['working'];
            $mate    = $state['total']['dyinggasp'];
            $ptok    = $state['total']['los'];
            $offline = $state['total']['offline'];
            $all     = $state['total']['all'];
    
            // --- Pastikan $text STRING, bukan array ---
            $text  = "Hallo $firstname $lastname!..\n";
            $text .= "Aku Bot OLTZTE!..🔥🔥🔥\n";
            $text = " Hallo $firstname $lastname!..\nAku Bot OLTZTE!..🔥🔥🔥\nLaguk anti, begak sue loading ne!..\n\nList Perintah {/ceklaser /setname /reboot /reset /delete /setssid}\n\n\n";
            $text .= "Total : $all\n";
            $text .= "Working : $idup\n";
            $text .= "DyingGasp : $mate\n";
            $text .= "LOS : $ptok\n";
            $text .= "Offline : $offline\n";
    
        } else {
    
            $text = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    
        // --- kirim edit message ---
        $options = [
            'chat_id' => $chatid,
            'message_id' => $message_id,
            'text' => $text,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔌 DyingGasp', 'callback_data' => 'cekdyinggasp'],
                        ['text' => '🚨 LOS', 'callback_data' => 'ceklos'],
                        ['text' => '💀 Offline', 'callback_data' => 'cekoffline'],
                    ],
                    [
                        ['text' => '📉 Redamantinggi', 'callback_data' => 'cekredamantinggi'],
                    ],
                ]
            ]),
            'parse_mode' => 'html'
        ];
    
        Bot::editMessageText($options);
    }
    


    elseif ($command === 'cekdyinggasp') {

        $update = Bot::message();
    
        // =============================
        // AMBIL CHAT & USER INFO
        // =============================
        $chatid = $update['chat']['id']
            ?? $update['message']['chat']['id']
            ?? $update['callback_query']['message']['chat']['id']
            ?? null;
    
        $message_id = $update['message_id']
            ?? $update['message']['message_id']
            ?? $update['callback_query']['message']['message_id']
            ?? null;
    
        $userid = $update['from']['id'] ?? 0;
    
        include 'koneksi.php';
    
        // =============================
        // CEK AKSES
        // =============================
        if ($chatid == $groupId || $userid == $yourid) {
    
            // =============================
            // AMBIL DATA STATE
            // =============================
            $stateAll = getState();
    
            if (!isset($stateAll['state']) || !is_array($stateAll['state'])) {
                $text = "❌ Gagal membaca data STATE.";
            } else {
    
                $name    = getName();
                $gpononu = getGpononu();
                $sn      = getSn();
    
                $text = "<b>🔌 DATA ONU DYINGGASP</b>\n\n";
                $no = 1;
                $adaData = false;
    
                // =============================
                // LOOP KHUSUS DYINGGASP
                // =============================
                foreach ($stateAll['state'] as $index => $row) {
    
                    if (!isset($row['status']) || $row['status'] !== 'DyingGasp') {
                        continue;
                    }
    
                    $adaData = true;
    
                    $text .= "No : {$no}\n";
                    $text .= "Nama : " . ($name[$index]['name'] ?? '-') . "\n";
                    $text .= "GponOnu : " . ($gpononu[$index]['nilai'] ?? '-') . "\n";
                    $text .= "Sn : " . ($sn[$index]['sn'] ?? '-') . "\n";
                    $text .= "State : DyingGasp\n";
                    $text .= "Laser : N/A\n\n";
    
                    $no++;
                }
    
                // =============================
                // JIKA TIDAK ADA DYINGGASP
                // =============================
                if (!$adaData) {
                    $text .= "✔ Semua ONU dalam kondisi normal.\nTidak ada ONU DyingGasp.";
                }
            }
    
        } else {
            $text = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    
        // =============================
        // KIRIM / EDIT PESAN
        // =============================
        Bot::editMessageText([
            'chat_id' => $chatid,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'html',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔙 Kembali', 'callback_data' => 'status'],
                    ],
                ]
            ])
        ]);
    }
    
    
    


    elseif ($command === 'ceklos') {

        $update = Bot::message();
    
        // =============================
        // AMBIL CHAT & USER INFO
        // =============================
        $chatid = $update['chat']['id']
            ?? $update['message']['chat']['id']
            ?? $update['callback_query']['message']['chat']['id']
            ?? null;
    
        $message_id = $update['message_id']
            ?? $update['message']['message_id']
            ?? $update['callback_query']['message']['message_id']
            ?? null;
    
        $userid = $update['from']['id'] ?? 0;
    
        include 'koneksi.php';
    
        // =============================
        // CEK AKSES
        // =============================
        if ($chatid == $groupId || $userid == $yourid) {
    
            // =============================
            // AMBIL DATA STATE
            // =============================
            $stateAll = getState();
    
            if (!isset($stateAll['state']) || !is_array($stateAll['state'])) {
                $text = "❌ Gagal membaca data STATE.";
            } else {
    
                $name    = getName();
                $gpononu = getGpononu();
                $sn      = getSn();
    
                $text = "<b>🚨 DATA ONU LOS</b>\n\n";
                $no = 1;
                $adaData = false;
    
                // =============================
                // LOOP KHUSUS LOS
                // =============================
                foreach ($stateAll['state'] as $index => $row) {
    
                    if (!isset($row['status']) || $row['status'] !== 'LOS') {
                        continue;
                    }
    
                    $adaData = true;
    
                    $text .= "No : {$no}\n";
                    $text .= "Nama : " . ($name[$index]['name'] ?? '-') . "\n";
                    $text .= "GponOnu : " . ($gpononu[$index]['nilai'] ?? '-') . "\n";
                    $text .= "Sn : " . ($sn[$index]['sn'] ?? '-') . "\n";
                    $text .= "State : LOS\n";
                    $text .= "Laser : N/A\n\n";
    
                    $no++;
                }
    
                // =============================
                // JIKA TIDAK ADA LOS
                // =============================
                if (!$adaData) {
                    $text .= "✔ Semua ONU dalam kondisi normal.\nTidak ada LOS ditemukan.";
                }
            }
    
        } else {
            $text = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    
        // =============================
        // KIRIM / EDIT PESAN
        // =============================
        Bot::editMessageText([
            'chat_id' => $chatid,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'html',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔙 Kembali', 'callback_data' => 'status'],
                    ],
                ]
            ])
        ]);
    }
    
    
    



    elseif ($command === 'cekoffline') {

        $update = Bot::message();
    
        // =============================
        // AMBIL CHAT & USER INFO
        // =============================
        $chatid = $update['chat']['id']
            ?? $update['message']['chat']['id']
            ?? $update['callback_query']['message']['chat']['id']
            ?? null;
    
        $message_id = $update['message_id']
            ?? $update['message']['message_id']
            ?? $update['callback_query']['message']['message_id']
            ?? null;
    
        $userid = $update['from']['id'] ?? 0;
    
        include 'koneksi.php';
    
        // =============================
        // CEK AKSES
        // =============================
        if ($chatid == $groupId || $userid == $yourid) {
    
            // =============================
            // AMBIL DATA
            // =============================
            $stateAll = getState();
    
            // validasi struktur state
            if (!isset($stateAll['state']) || !is_array($stateAll['state'])) {
                $text = "❌ Gagal membaca data STATE.";
            } else {
    
                $name    = getName();
                $gpononu = getGpononu();
                $sn      = getSn();
    
                $text = "<b>💀 DATA ONU OFFLINE</b>\n\n";
                $no = 1;
                $adaData = false;
    
                // =============================
                // LOOP KHUSUS ONU OFFLINE
                // =============================
                foreach ($stateAll['state'] as $index => $row) {
    
                    if (!isset($row['status']) || $row['status'] !== 'OFFLINE') {
                        continue;
                    }
    
                    $adaData = true;
    
                    $text .= "No : {$no}\n";
                    $text .= "Nama : " . ($name[$index]['name'] ?? '-') . "\n";
                    $text .= "GponOnu : " . ($gpononu[$index]['nilai'] ?? '-') . "\n";
                    $text .= "Sn : " . ($sn[$index]['sn'] ?? '-') . "\n";
                    $text .= "State : OFFLINE\n";
                    $text .= "Laser : N/A\n\n";
    
                    $no++;
                }
    
                // =============================
                // JIKA TIDAK ADA OFFLINE
                // =============================
                if (!$adaData) {
                    $text .= "✔ Semua ONU dalam kondisi normal.\nTidak ada ONU OFFLINE.";
                }
            }
    
        } else {
            $text = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    
        // =============================
        // KIRIM / EDIT PESAN
        // =============================
        Bot::editMessageText([
            'chat_id' => $chatid,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'html',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔙 Kembali', 'callback_data' => 'status'],
                    ],
                ]
            ])
        ]);
    }
    
    
    
    


    elseif ($command === 'cekredamantinggi') {

        $update = Bot::message();
    
        // =============================
        // AMBIL CHAT & USER INFO
        // =============================
        $chatid = $update['chat']['id']
            ?? $update['message']['chat']['id']
            ?? $update['callback_query']['message']['chat']['id']
            ?? null;
    
        $message_id = $update['message_id']
            ?? $update['message']['message_id']
            ?? $update['callback_query']['message']['message_id']
            ?? null;
    
        $userid = $update['from']['id'] ?? 0;
    
        include 'koneksi.php';
    
        // =============================
        // CEK AKSES
        // =============================
        if ($chatid == $groupId || $userid == $yourid) {
    
            // =============================
            // JEDA SEBENTAR agar file redamantinggi.txt stabil
            // =============================
            usleep(500000); // 0.5 detik
    
            // =============================
            // AMBIL DATA DARI redamantinggi.txt
            // =============================
            $laser    = getLaser();    // array redaman tinggi
            $name     = getName2();    // Nama ONT
            $gpononu  = getGpononu2(); // GPON-ONU
            $sn       = getSn2();      // Serial Number
    
            $pesan = "<b>📉 DATA ONU REDAMAN TINGGI</b>\n\n";
            $no = 1;
    
            foreach ($laser as $index => $laserData) {
                $redamanText = $laserData['nilai'] ?? '-';
    
                $pesan .= "No : {$no}\n";
                $pesan .= "Nama : " . ($name[$index]['name'] ?? '-') . "\n";
                $pesan .= "GponOnu : " . ($gpononu[$index]['nilai'] ?? '-') . "\n";
                $pesan .= "Sn : " . ($sn[$index]['nilai'] ?? '-') . "\n";
                $pesan .= "State : Working\n";
                $pesan .= "Laser : " . $redamanText . " dBm\n\n";
    
                $no++;
            }
    
            if ($no === 1) {
                $pesan .= "Tidak ada data redaman tinggi.";
            }
    
        } else {
            $pesan = "Maaf..! Akses hanya untuk Administrator 😱";
        }
    
        // =============================
        // KIRIM / EDIT PESAN
        // =============================
        Bot::editMessageText([
            'chat_id' => $chatid,
            'message_id' => $message_id,
            'text' => $pesan,
            'parse_mode' => 'html',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '🔙 Kembali', 'callback_data' => 'status'],
                    ],
                ]
            ])
        ]);
    }
    
    
    
    
    
    
    
    
    
    


});
$bot->run();