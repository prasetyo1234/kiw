<?php
$servername = "localhost";
$database = "snmp";
$username = "root";
$password = "Crazylags1";


$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$query = "SELECT * FROM snmpwalk";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    //koneksi snmp
    $ip = $row['ip'];
    $community = $row['community'];
    $port = $row['port'];
    //koneksi telegram
    $token = $row['token'];
    $yourid = $row['yourid'];
    $groupId = $row['groupid'];
    //koneksi telnet
    $usertel = $row['usertel'];
    $passtel = $row['passtel'];
    $porttel = $row['porttel'];
}
?>