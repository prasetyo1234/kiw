<?php
session_start();
if (!isset($_SESSION['username'])) { 
  header("Location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
  <title>Activation Form</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<div class="header">
  <div class="d-flex justify-content-between align-items-center">
    <button class="btn btn-sm btn-dark d-md-none" id="toggle-sidebar">
      <span style="font-size: 18px; color: #fff;">&#9776;</span>
    </button>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle-no-caret" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fab fa-playstation" style="color: silver;"></i>
      </a>
    </div>
  </div>
</div>
<div class="container" style="margin-top: 75px; border-radius: 5px;">
  <div class="sidebar" id="sidebar">
  <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link text-white" href="index.php"><i class="fa fa-home"></i> Dashboard</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="connection.php"><i class="fa fa-plug"></i> Connection</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="activation.php"><i class="fa fa-power-off"></i> Activation</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="users.php"><i class="fa fa-users"></i> Users</a>
      </li>
    </ul>
  </div>
  <div class="content">

    <div class="row">
      <div class="col-md-6 offset-md-3">
        <h2 class="text-white">Activation Via Telnet</h2>
        <?php include 'gettelnet.php'; ?>
        <form id="form-activation" method="post" action="telnet.php" class=" text-white p-3">
        <div class="form-group">
        <label for="regisonu">Serial Number:</label>
        <select name="regisonu" class="form-control bg-dark text-white" required>
          <?php echo get_intsn(); ?>
        </select>
        </div>
        <hr class="border-primary">
          <div class="form-group row">
            <div class="col-6">
              <label for="onutype">Onu Type:</label>
              <select name="onutype" class="form-control bg-dark text-white" required>
                <?php echo get_onutype(); ?>
              </select>
            </div>
            <div class="col-6">
              <label for="profiletype">Profile Type:</label>
              <select name="profiletype" class="form-control bg-dark text-white" required>
                <?php echo get_profiletype(); ?>
              </select>
            </div>
          </div>
          <div class="form-group row">
          <div class="col-6">
            <label for="name">Name:</label>
            <input type="text" name="name" value="" class="form-control bg-dark text-white" required>
          </div>
          <div class="col-6">
            <label for="deskripsi">Description:</label>
            <input type="text" name="deskripsi" value="" class="form-control bg-dark text-white">
          </div>
        </div>
        <hr class="border-primary">
        <p class="text-center">isi jika menggunakan hotspot</p>
        <div class="form-group row">
  <div class="col-4">
    <label for="vlanhot">Vlan:</label>
    <input type="number" name="vlanhot" value="" class="form-control bg-dark text-white">
  </div>
  <div class="col-6" style="margin-top: 0px;">
    <label>Tags:</label>
    <div class="row" style="margin-top: -5px;">
      <div class="col-4">
        <div class="form-check">
          <input type="checkbox" name="port[]" value="eth_0/1" class="form-check-input" id="eth01">
          <label class="form-check-label" for="eth01">eth1</label>
        </div>
        <div class="form-check">
          <input type="checkbox" name="port[]" value="eth_0/2" class="form-check-input" id="eth02">
          <label class="form-check-label" for="eth02">eth2</label>
        </div>
      </div>
      <div class="col-4">
        <div class="form-check">
          <input type="checkbox" name="port[]" value="eth_0/3" class="form-check-input" id="eth03">
          <label class="form-check-label" for="eth03">eth3</label>
        </div>
        <div class="form-check">
          <input type="checkbox" name="port[]" value="eth_0/4" class="form-check-input" id="eth04">
          <label class="form-check-label" for="eth04">eth4</label>
        </div>
      </div>
      <div class="col-4">
        <div class="form-check">
          <input type="checkbox" name="port[]" value="wifi_0/1" class="form-check-input" id="wifi01">
          <label class="form-check-label" for="wifi01">ssid1</label>
        </div>
        <div class="form-check">
          <input type="checkbox" name="port[]" value="wifi_0/5" class="form-check-input" id="wifi05">
          <label class="form-check-label" for="wifi05">ssid5</label>
        </div>
      </div>
    </div>
    </div>
  </div>
  <div class="form-group">
  <label for="ssidhot">Ssid:</label>
  <input type="text" name="ssidhot" value="" class="form-control bg-dark text-white">
  </div>
  <hr class="border-primary">
  <p class="text-center">isi jika menggunakan pppoe</p>
  <div class="form-group row">
    <div class="col-4">
        <label for="vlanppp">Vlan:</label>
        <input type="number" name="vlanppp" value="" class="form-control bg-dark text-white">
    </div>
    <div class="col-4">
        <label for="userppp">Username:</label>
        <input type="text" name="userppp" value="" class="form-control bg-dark text-white">
    </div>
    <div class="col-4">
        <label for="passppp">Password:</label>
        <input type="text" name="passppp" value="" class="form-control bg-dark text-white">
    </div>

</div>
      <div class="form-group row">
      <div class="col-4">
        <label for="ssidppp">Ssid:</label>
        <input type="text" name="ssidppp" value="" class="form-control bg-dark text-white">
      </div>
      <div class="col-4">
        <label for="pass2ppp">PassWPA2:</label>
        <input type="text" name="pass2ppp" value="" class="form-control bg-dark text-white">
      </div>
      <div class="col-4 px-2">
        <label for="profilevlan">Vlan Profile:</label>
        <select name="profilevlan" class="form-control bg-dark text-white" required>
            <?php echo get_profile_vlan(); ?>
        </select>
    </div>
      </div>
      <hr class="border-primary">
      <p class="text-center">isi jika menggunakan ip static</p>
      <div class="form-group row">
      <div class="col-6">
        <label for="vlansta">Vlan:</label>
        <input type="number" name="vlansta" value="" class="form-control bg-dark text-white">
      </div>
      <div class="col-6">
        <label for="ipsta">IP Static:</label>
        <input type="number" name="ipsta" value="" class="form-control bg-dark text-white">
      </div>
    </div>
    <div class="form-group row">
            <div class="col-6">
        <label for="profileip">IP Profile:</label>
        <select name="profileip" class="form-control bg-dark text-white" required>
            <?php echo get_profile_ip(); ?>
        </select>
    </div>
    <div class="col-6">
        <label for="profilevlan">Vlan Profile:</label>
        <select name="profilevlans" class="form-control bg-dark text-white" required>
            <?php echo get_profile_vlan(); ?>
        </select>
    </div>
      </div>
      <div class="text-center">
      <button type="submit" name="submit" value="submit" class="btn btn-primary" style="background-color: #7e3af2;">Gass Wah Boss..</button>
      </div>
      </form>
      </div>
    </div>
  </div>

</div>
</div>
<div class="footer">
  <!-- konten footer -->
  <p>&copy; 2025 Muhammad Ilham | Pancor Sanggeng. All rights reserved.</p>
  <span class="version">v1.2</span>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  $(document).ready(function () {
  $('#toggle-sidebar').on('click', function (e) {
    e.stopPropagation();
    $('#sidebar').toggleClass('active');
  });
  $(document).on('click', function () {
    if ($(window).width() < 769) {
      $('#sidebar').removeClass('active');
    }
  });
  $('#sidebar').on('click', function (e) {
    e.stopPropagation();
  });
});
//activation
$('#form-activation').submit(function(e) {
  e.preventDefault();
  var $form = $(this);
  var formData = $form.serialize() + '&submit=submit';
  Swal.fire({
    html: '<div class="loading mx-auto"></div>',
    allowOutsideClick: false,
    allowEscapeKey: false,
    showConfirmButton: false,
    background: 'transparent'
  });
  $.ajax({
    type: 'POST',
    url: 'telnet.php',
    data: formData,
    success: function(data) {
      Swal.close();
      if (data.includes("Berhasil")) {
        Swal.fire({
          icon: 'success',
          title: 'Mantul!',
          text: data,
        });
      } else {
        Swal.fire({
          icon: 'success',
          title: 'Mantul!',
          text: data,
        });
      }
    },
    error: function(xhr, status, error) {
      Swal.close();
      Swal.fire({
        icon: 'error',
        title: 'Gagal!',
        text: 'Cek koneksi juluk!',
      });
    }
  });
});
</script>
</body>
</html>