<?php
session_start();
if (!isset($_SESSION['username'])) { 
  header("Location: login.php");
  exit;
}

include 'koneksi.php';
$query = mysqli_query($conn, "SELECT * FROM snmpwalk");
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title></title>
    <!-- TABLE STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


    <div class="header"> 
  <div class="d-flex justify-content-between align-items-center position-relative">
    <button class="btn btn-sm btn-dark d-md-none" id="toggle-sidebar">
      <span style="font-size: 18px; color: silver;">&#9776;</span>
    </button>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle-no-caret p-0" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <span class="position-relative status-item">
        <i class="fa fa-bell" style="color: silver;"></i>
      <span class="position-absolute top-0 end-0 rounded-circle animate-pulse" style="top: 0px; right: -2px; width: 8px; height: 8px; background-color: red; border-radius: 50%;"></span>
      </span>
      </a>
      <div class="dropdown-menu dropdown-menu-dark dropdown-menu-right" aria-labelledby="navbarDropdown">
        <li class="dropdown-item" href="#">Messages <span class="badge badge-danger">12</span></li>
        <li class="dropdown-item" href="#">Sales <span class="badge badge-danger">4</span></li>
        <li class="dropdown-item" href="#">Alerts</li>
      </div>
    </div>
    <div class="nav-item dropdown ml-3"> 
      <a class="nav-link dropdown-toggle-no-caret" href="#" id="navbarDropdownProfile" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-user" style="color: silver;"></i>
      </a>
      <div class="dropdown-menu dropdown-menu-dark dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
        <li class="dropdown-item" href="#"><i class="fa fa-user"></i> Profile</li>
        <li class="dropdown-item" href="#"><i class="fa fa-gear"></i> Settings</li>
        <li class="dropdown-item"><a href="logout.php" style="text-decoration: none"><i class="fa fa-sign-out"></i> Logout</a></li>
      </div>
    </div>
  </div>
</div>




<div class="container" style="margin-top: 180px;">
  <div class="sidebar" id="sidebar">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="connection.php"><i class="fa fa-plug"></i> Connection</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="activation.php"><i class="fa fa-power-off"></i> Activation</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="users.php"><i class="fa fa-users"></i> Users</a>
      </li>
    </ul>
  </div>




                    <!-- Modal Tambah -->
                    <div class="modal fade" id="tambahUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel" style="color:black;">Tambah:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                    <div class="modal-body">
                        <form action="" method="post">
                            <div class="form-group" style="color:black;">
                            <label for="snmp">SNMP</label>
                            <br>
                                <label for="ipa">IP:</label>
                                <input type="text" class="form-control" id="ipa" required="" name="ipa" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="communitya">Community:</label>
                                <input type="text" class="form-control" id="communitya" required="" name="communitya" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="porta">Port:</label>
                                <input type="number" class="form-control" id="porta" required="" name="porta" value="">
                            </div>

                            <div class="form-group" style="color:black;">
                            <label for="snmp">TELNET</label>
                            <br>
                                <label for="usertela">Username:</label>
                                <input type="text" class="form-control" id="usertela" name="usertela" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="passtela">Password:</label>
                                <input type="text" class="form-control" id="passtela" name="passtela" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="porttela">Port:</label>
                                <input type="number" class="form-control" id="porttela" name="porttela" value="">
                            </div>

                            <div class="form-group" style="color:black;">
                            <label for="telegram">TELEGRAM</label>
                            <br>
                                <label for="tokena">Token:</label>
                                <input type="text" class="form-control" id="tokena" name="tokena" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="chatida">ChatID:</label>
                                <input type="text" class="form-control" id="chatida" name="chatida" value="">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="groupida">ChatGroipID:</label>
                                <input type="text" class="form-control" id="groupida" name="groupida" value="">
                            </div>
                        
                            <div class="modal-footer">
                                <input type="hidden" id="create" name="date" value="">
                                <div class="btn-group">
                                    <button type='submit' name='add' class='btn btn-info'>
                                    <i class="fa fa-save"></i> Simpan
                                    </button>
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                                    <i class="fa fa-close"></i> Close
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>





  <div class="content">

  <a id="add" class="btn btn-primary" style="background-color: #7e3af2;" data-toggle="modal" data-target="#tambahUserModal">
    <i class="fa fa-plus"></i> Tambah Koneksi
  </a>
    <table class="table table-dark table-striped" style="background-color: #2f3a50;">
      <thead>
        <tr>
          <th class="text-white">ID</th>
          <th class="text-white">IP</th>
          <th class="text-white">Community</th>
          <th class="text-white">Port</th>
          <th class="text-white">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($query)) { ?>
        <tr>
          <td class="text-white"><?php echo $row['id']; ?></td>
          <td class="text-white"><?php echo $row['ip']; ?></td>
          <td class="text-white"><?php echo $row['community']; ?></td>
          <td class="text-white"><?php echo $row['port']; ?></td>
          <td>
                    <div class="dropdown d-flex justify-content-around">
                    <button class="btn btn-sm dropdown-toggle-no-caret btn-link" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="icon-label" style="color:silver;"><i class="fa fa-cog"></i></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <li>
                        <button class="btn btn-sm" href="#edit<?php echo $row['id']; ?>" data-toggle="modal">
                            <span class="icon-label"><i class="fa fa-edit"></i> Edit</span>
                        </button>
                        </li>
                        <li>
                        <button class="btn btn-sm" onclick="deleteUser('<?php echo $row['id']; ?>', '<?php echo $row['ip']; ?>')">
                            <span class="icon-label"><i class="fa fa-trash"></i> Hapus</span>
                        </button>
                        </li>
                    </ul>
                    </div>
                </td>
        </tr>











            <!-- Modal Update -->
            <div class="modal fade" id="edit<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel" style="color:black;">Update:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                    <div class="modal-body">
                        <form action="" method="post">
                            <div class="form-group" style="color:black;">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>"
                                <label for="snmp">SNMP</label>
                                <br>
                                <label for="ip">IP:</label>
                                <input type="text" class="form-control" id="ip" required="" name="ip" value="<?php echo $row['ip']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="community">Community:</label>
                                <input type="text" class="form-control" id="community" required="" name="community" value="<?php echo $row['community']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="port">Port:</label>
                                <input type="number" class="form-control" id="port" required="" name="port" value="<?php echo $row['port']; ?>">
                            </div>

                            <div class="form-group" style="color:black;">
                                <label for="telnet">TELNET</label>
                                <br>
                                <label for="usertelu">Username:</label>
                                <input type="text" class="form-control" id="usertelu" name="usertelu" value="<?php echo $row['usertel']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="passtelu">Password:</label>
                                <input type="text" class="form-control" id="passtelu" name="passtelu" value="<?php echo $row['passtel']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="porttelu">Port:</label>
                                <input type="number" class="form-control" id="porttelu" name="porttelu" value="<?php echo $row['porttel']; ?>">
                            </div>

                            <div class="form-group" style="color:black;">
                            <label for="telegram">TELEGRAM</label>
                            <br>
                                <label for="tokenu">Token:</label>
                                <input type="text" class="form-control" id="tokenu" name="tokenu" value="<?php echo $row['token']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="chatidu">ChatID:</label>
                                <input type="number" class="form-control" id="chatidu" name="chatidu" value="<?php echo $row['yourid']; ?>">
                            </div>
                            <div class="form-group" style="color:black;">
                                <label for="groupidu">ChatGroupID:</label>
                                <input type="number" class="form-control" id="groupidu" name="groupidu" value="<?php echo $row['groupid']; ?>">
                            </div>
                        
                            <div class="modal-footer">
                                <input type="hidden" id="create" name="date" value="">
                                <div class="btn-group">
                                    <button type='submit' name='edit' class='btn btn-info'>
                                    <i class="fa fa-save"></i> Simpan
                                    </button>
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                                    <i class="fa fa-close"></i> Close
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>




        <?php } ?>
      </tbody>
    </table>

</div>
</div>

<div class="footer">
  <!-- konten footer -->
  <p>&copy; 2025 Muhammad Ilham | Pancor Sanggeng. All rights reserved.</p>
  <span class="version">v1.2</span>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>

<script>
  //update
$('form').submit(function(e) {
  e.preventDefault();
  var $form = $(this);
  var formData = $form.serialize();
  var modal = $form.closest('.modal');
  modal.modal('hide');
  Swal.fire({
      html: '<div class="loading mx-auto"></div>',
      allowOutsideClick: false,
      allowEscapeKey: false,
      showConfirmButton: false,
      background: 'transparent'
  });
  $.ajax({
      type: 'POST',
      url: 'update.php',
      data: formData,
      success: function(data) {
          Swal.close();
          if (data.includes("Berhasil")) {
              Swal.fire({
                  icon: 'success',
                  title: 'Mantul!',
                  text: data,
              });
          } else {
              Swal.fire({
                  icon: 'error',
                  title: 'Gagal!',
                  text: data,
              });
          }
      },
      error: function() {
          Swal.close();
          Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Cek koneksi juluk!',
          });
      }
  });
});
//delete
function deleteUser(idUser, userName) {
  Swal.fire({
    title: 'Yakin iti ngapus ROTER?',
    text: `Gin ne te apus ${userName} ine!`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Aok!',
    cancelButtonText: 'Ndak'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        html: '<div class="loading mx-auto"></div>',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        background: 'transparent'
      });
      $.ajax({
        type: 'POST',
        url: 'update.php',
        data: {
          iddeletes: idUser,
        },
        success: function(data) {
          Swal.close();
          if (data.includes("Berhasil")) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: `wah apus ${userName} mantap`,
              showConfirmButton: true, // ubah menjadi true
            })
          } else {
            Swal.fire('Gagal!', data, 'error')
          }
        },
        error: function() {
          Swal.close();
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Cek koneksi juluk!',
          })
        }
      });
    }
  })
}
//animasi slidebar
$(document).ready(function () {
  $('#toggle-sidebar').on('click', function (e) {
    e.stopPropagation();
    $('#sidebar').toggleClass('active');
  });
  $(document).on('click', function () {
    if ($(window).width() < 769) {
      $('#sidebar').removeClass('active');
    }
  });
  $('#sidebar').on('click', function (e) {
    e.stopPropagation();
  });
});
</script>