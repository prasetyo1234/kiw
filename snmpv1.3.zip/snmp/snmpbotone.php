<?php
require 'vendor/autoload.php';
require 'koneksi.php';

use FreeDSx\Snmp\SnmpClient;

/**
 * getOne
 * Ambil data ONU berdasarkan NAMA (lookup di file map)
 */
function getOne($searchName) {
    global $ip, $port, $community;

    // ===== LOAD MAP FILE =====
    $mapFile = __DIR__ . '/onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return ['status'=>'error','message'=>'File onu_index_map.txt tidak ditemukan'];
    }

    $map = json_decode(file_get_contents($mapFile), true);

    // ===== CARI INDEX BERDASARKAN NAMA =====
    $onuIndex = null;
    foreach ($map as $index => $info) {
        if (strcasecmp($info['name'], $searchName) === 0) {
            $onuIndex = $index;
            break;
        }
    }

    if ($onuIndex === null) {
        return ['status'=>'error','message'=>"Nama ONU '$searchName' tidak ditemukan di map"];
    }

    $info = $map[$onuIndex];

    // ===== SNMP CLIENT =====
    $snmp = new SnmpClient([
        'host'      => $ip,
        'port'      => $port,
        'community' => $community,
        'version'   => 2,
    ]);

    $oidMap = [
        'name'  => '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2',
        'type'  => '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.1',
        'desc'  => '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.3',
        'sn'    => '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.18',
        'state' => '1.3.6.1.4.1.3902.1082.500.10.2.3.8.1.4',
        'laser' => '1.3.6.1.4.1.3902.1082.500.20.2.2.2.1.10',
    ];

    try {
        // ===== GET ONU INFO =====
        $res = $snmp->get(
            $oidMap['name'].".$onuIndex",
            $oidMap['type'].".$onuIndex",
            $oidMap['desc'].".$onuIndex",
            $oidMap['sn'].".$onuIndex",
            $oidMap['state'].".$onuIndex"
        );

        // Ambil nilai state dan konversi ke teks
        $stateRaw = $res->get($oidMap['state'].".$onuIndex")->getValue();
        $stateInt = is_object($stateRaw) ? (int)$stateRaw->getValue() : (int)$stateRaw;

        switch ($stateInt) {
            case 7: $stateText = 'Offline'; break;
            case 4: $stateText = 'Working'; break;
            case 5: $stateText = 'DyingGasp'; break;
            case 2: $stateText = 'LOS'; break;
            default: $stateText = 'Unknown';
        }

        // ===== GET LASER RX (.1) =====
        $laserOid = $oidMap['laser'].".$onuIndex.1";
        $laserVal = 'N/A';
        $laserRes = $snmp->get($laserOid);
        if ($laserRes !== null && $laserRes->get($laserOid) !== null) {
            $valObj = $laserRes->get($laserOid)->getValue();
            $raw = is_object($valObj) ? (int)$valObj->getValue() : (int)$valObj;
            if ($raw < 32768) {
                $laserVal = number_format((($raw * 0.002) - 30.0), 2, '.', '');
            } elseif ($raw < 65535) {
                $laserVal = number_format((-30 - ((65535 - $raw) * 0.002)), 2, '.', '');
            }
        }

        $snRaw = (string)$res->get($oidMap['sn'].".$onuIndex")->getValue();

        // ===== FINAL DATA =====
        $data = [
            'status' => 'success',
            'data' => [
                'index'     => $onuIndex,
                'name'      => (string)$res->get($oidMap['name'].".$onuIndex")->getValue(),
                'type'      => (string)$res->get($oidMap['type'].".$onuIndex")->getValue(),
                'desc'      => (string)$res->get($oidMap['desc'].".$onuIndex")->getValue(),
                'sn'        => preg_replace('/^1,/', '', $snRaw),
                'state'     => $stateText,
                'laser'     => $laserVal,
                'interface' => $info['interface']
            ]
        ];

        // ===== RETURN DATA LANGSUNG TANPA FILE =====
        return $data;

    } catch (\Exception $e) {
        return ['status'=>'error','message'=>$e->getMessage()];
    }
}

// ===== CONTOH PANGGIL =====
//$result = getOne('ULOH1');
//print_r($result);
