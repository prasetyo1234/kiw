<?php
require 'vendor/autoload.php';
require 'koneksi.php';
use FreeDSx\Snmp\Exception\SnmpRequestException;
use FreeDSx\Snmp\Oid;
use FreeDSx\Snmp\SnmpClient;

global $ip, $port, $community;
$snmp = new SnmpClient([
    'host' => $ip,
    'port' => $port,
    'community' => $community,
]);

//gantinamaonu
if (isset($_POST['idname']) && isset($_POST['valuename'])) {
    $idname = $_POST['idname'];
    $valuename = $_POST['valuename'];
try {
    $snmp->set(Oid::fromString($idname, $valuename));
    echo "Nama Berhasil Diubah ke $valuename dan ";
} catch (SnmpRequestException $e) {
    echo $e->getMessage();
}
}

//gantides
if (isset($_POST['iddes']) && isset($_POST['valuedes'])) {
    $iddes = $_POST['iddes'];
    $valuedes = $_POST['valuedes'];
try {
    $snmp->set(Oid::fromString($iddes, $valuedes));
    echo "Deskripsi Berhasil Diubah ke $valuedes";
} catch (SnmpRequestException $e) {
    echo $e->getMessage();
}
}

//rebootonu
elseif (isset($_POST['idreboot']) && isset($_POST['valuereboot'])) {
    $idreboot = $_POST['idreboot'];
    $valuereboot = $_POST['valuereboot'];
    // Ubah $idreboot
    $idreboot = str_replace('1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2', '1.3.6.1.4.1.3902.1082.500.20.2.1.10.1.1', $idreboot);
try {
    $snmp->set(Oid::fromInteger($idreboot, $valuereboot));
    echo "Berhasil Direboot";
} catch (SnmpRequestException $e) {
    echo $e->getMessage();
    exit;
}
}


//resetonu
elseif (isset($_POST['idreset']) && isset($_POST['valuereset'])) {
    $idreset = $_POST['idreset'];
    $valuereset = $_POST['valuereset'];
    // Ubah $idreset
    $idreset = str_replace('1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2', '1.3.6.1.4.1.3902.1082.500.20.2.1.10.1.4', $idreset);
    try {
        $snmp->set(Oid::fromInteger($idreset, $valuereset));
        echo "Berhasil Direset";
    } catch (SnmpRequestException $e) {
        echo $e->getMessage();
        exit;
    }
}



//deleteonu
elseif (isset($_POST['iddelete']) && isset($_POST['valuedelete'])) {
    $iddelete = $_POST['iddelete'];
    $valuedelete = $_POST['valuedelete'];
    // Ubah $iddelete
    $iddelete = str_replace('1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2', '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.50', $iddelete);
    try {
        $snmp->set(Oid::fromInteger($iddelete, $valuedelete));
        echo "Berhasil Dihapus";
    } catch (SnmpRequestException $e) {
        echo $e->getMessage();
        exit;
    }
}


//refresh data onu
if (isset($_POST['idlaser']) && isset($_POST['idstate']) && isset($_POST['idname'])) {

    $idlaser = $_POST['idlaser'];
    $idstate = $_POST['idstate'];
    $idname  = $_POST['idname'];

    try {
        // Ambil nilai laser
        $oid = $snmp->getOid($idlaser);
        $nilai = $oid->getValue()->getValue();

        // Konversi nilai Rx
        if ($nilai < 32768) {
            $nilai = ($nilai * 0.002) - 30.0;
        } elseif ($nilai < 65535) {
            $nilai = (-30 - ((65535 - $nilai) * 0.002));
        } else {
            $nilai = 'N/A';
        }

        $containerWidth = '90px'; // lebar container tetap

        if ($nilai === 'N/A') {

            // ===== GENERATE BAR KOSONG =====
            $barHeights = [4, 8, 12, 16];
            $barHtml = '<span style="display:flex;align-items:flex-end;gap:1px;">';
            foreach ($barHeights as $height) {
                $barHtml .= '<span style="
                        width:3px;
                        height:' . $height . 'px;
                        background:rgba(200,200,200,0.2);
                        border-radius:1px;
                    "></span>';
            }
            $barHtml .= '</span>';

            $color = '#f14e4e';
            $backgroundColor = 'rgba(241,78,78,.08)';

            $laser_value = '
            <span style="
                display:flex;
                align-items:center;
                justify-content:center; /* teks di tengah */
                gap:4px; /* jarak bar dan teks */
                padding:0 4px;
                height:30px;
                color:' . $color . ';
                background:' . $backgroundColor . ';
                border-radius:5px;
                font-weight:500;
                min-width:' . $containerWidth . ';
                max-width:' . $containerWidth . ';
                overflow:hidden;
                font-size:12px;
            ">
                ' . $barHtml . '
                <span>N/A</span>
            </span>';

        } else {

            // ===== WARNA & JUMLAH BAR SESUAI REDAMAN =====
            if ($nilai >= -25) {
                $color = '#28a745';
                $backgroundColor = 'rgba(40,167,69,.08)';
                $bars = 4;
            } elseif ($nilai >= -27.99) {
                $color = '#c9b800';
                $backgroundColor = 'rgba(255,220,100,.10)';
                $bars = 3;
            } elseif ($nilai >= -29.99) {
                $color = '#fd7e14';
                $backgroundColor = 'rgba(253,126,20,.10)';
                $bars = 2;
            } else {
                $color = '#f14e4e';
                $backgroundColor = 'rgba(241,78,78,.08)';
                $bars = 1;
            }

            // ===== GENERATE BAR =====
            $barHeights = [4, 8, 12, 16];
            $barHtml = '<span style="display:flex;align-items:flex-end;gap:1px;">';
            for ($i = 1; $i <= 4; $i++) {
                $height = $barHeights[$i - 1];
                $opacity = ($i <= $bars) ? '1' : '.2';
                $barHtml .= '<span style="
                        width:3px;
                        height:' . $height . 'px;
                        background:' . $color . ';
                        opacity:' . $opacity . ';
                        border-radius:1px;
                    "></span>';
            }
            $barHtml .= '</span>';

            $laser_value = '
            <span style="
                display:flex;
                align-items:center;
                justify-content:center; /* teks di tengah */
                gap:4px;
                padding:0 4px;
                height:30px;
                color:' . $color . ';
                background:' . $backgroundColor . ';
                border-radius:5px;
                font-weight:500;
                min-width:' . $containerWidth . ';
                max-width:' . $containerWidth . ';
                overflow:hidden;
                font-size:12px;
            ">
                ' . $barHtml . '
                <span>' . number_format($nilai, 2) . ' dBm</span>
            </span>';
        }


    

    // Mendapatkan status baru
    $oid_status = $snmp->getOid($idstate);
    $status = $oid_status->getValue()->getValue();
    switch ($status) {

        case '4': // WORKING
            $state_value = '
            <span style="
                display:inline-flex;
                width:90px;
                height:30px;
                justify-content:center;
                align-items:center;
                color:#28a745;
                background-color:rgba(35,197,143,.08);
                border-radius:5px;
            ">Working</span>';
            break;
    
        case '5': // DYING GASP
            $state_value = '
            <span style="
                display:inline-flex;
                width:90px;
                height:30px;
                justify-content:center;
                align-items:center;
                color:#cccc00;
                background-color:rgba(255,220,100,.10);
                border-radius:5px;
            ">DyingGasp</span>';
            break;
    
        case '2': // LOS
            $state_value = '
            <span style="
                display:inline-flex;
                width:90px;
                height:30px;
                justify-content:center;
                align-items:center;
                color:#f14e4e;
                background-color:rgba(241,78,78,.08);
                border-radius:5px;
            ">LOS</span>';
            break;
    
        case '7': // OFFLINE
            $state_value = '
            <span style="
                display:inline-flex;
                width:90px;
                height:30px;
                justify-content:center;
                align-items:center;
                color:#fd7e14;
                background-color:rgba(253,126,20,.10);
                border-radius:5px;
            ">OFFLINE</span>';
            break;
    
        default:
            $state_value = '';
            break;
    }
    

    // Mendapatkan nama baru
    $oid_name = $snmp->getOid($idname);
    $name_value = $oid_name->getValue()->getValue();


    // Mengembalikan data dalam format JSON
    $result = array(
        'laser' => $laser_value,
        'state' => $state_value,
        'name' => $name_value
    );
    echo json_encode($result);
} catch (SnmpRequestException $e) {
    echo json_encode(array('error' => $e->getMessage()));
}
}
?>