<?php
require 'vendor/autoload.php';
require 'koneksi.php';
use FreeDSx\Snmp\SnmpClient;


function getBoard($saveToFile = true) {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
        'version' => 2,
    ]);

    $oids = ['1.3.6.1.4.1.3902.1082.10.1.2.4.1.4.1.1'];
    $data = [];

    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);

            while ($walk->hasOids()) {
                $oid_value = $walk->next();
                $value = $oid_value->getValue();

                if (is_object($value)) {
                    $value = (string) $value;
                }

                if (trim($value) !== '') {
                    // Ambil index terakhir dari OID
                    $oidParts = explode('.', $oid_value->getOid());
                    $index = end($oidParts);

                    // Simpan sesuai index
                    $data[(int)$index] = $value;
                }
            }

        } catch (\Exception $e) {
            // Lewat jika error SNMP
        }
    }

    // Urutkan array sesuai key agar JSON tersimpan rapi
    ksort($data);

    // Simpan ke file jika diinginkan
    if ($saveToFile) {
        file_put_contents('slots.txt', json_encode($data, JSON_PRETTY_PRINT));
    }

    return $data;
}




function getName() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    $oids = array(
        '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2',
    );

    $data = array();
    $no = 1;

    // ===== TAMBAHAN: penampung data TXT =====
    $txtData = array();
    // ======================================

    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);

            if (!$walk->hasOids()) {
                $data[] = array(
                    'no' => $no,
                    'nilai' => 'Tidak ada data',
                    'onu_id' => '',
                );
                $no++;
            } else {
                while ($walk->hasOids()) {
                    $oid_value = $walk->next();

                    $oid_parts = explode('.', $oid_value->getOid());
                    array_shift($oid_parts); // Hilangkan OID utama

                    $onu_id = $oid_value;

                    $data[] = array(
                        'no' => $no,
                        'nilai' => $oid_value->getValue(),
                        'onu_id' => $onu_id,
                    );

                    // ===== TAMBAHAN: simpan baseindex.onuid + slot + port =====
                    $fullOid  = $oid_value->getOid();
                    $oidParts = explode('.', $fullOid);

                    // Ambil dua index terakhir dari OID
                    $onuId     = (int) array_pop($oidParts);
                    $baseIndex = (int) array_pop($oidParts);

                    // === HITUNG SLOT & PORT (GPON 16 PORT) ===
                    $slot_calc = null;
                    $port_calc = null;

                    $BASE_INDEX  = 285278465;
                    $PORT_OFFSET = 256;
                    $MAX_PORT    = 16;

                    if ($baseIndex >= $BASE_INDEX) {
                        $diff = $baseIndex - $BASE_INDEX;
                        $slot_tmp = floor($diff / $PORT_OFFSET) + 1;
                        $port_tmp = ($diff % $PORT_OFFSET) + 1;

                        if ($port_tmp >= 1 && $port_tmp <= $MAX_PORT) {
                            $slot_calc = $slot_tmp;
                            $port_calc = $port_tmp;
                        }
                    }
                    // =======================================

                    $key  = $baseIndex . '.' . $onuId;
                    $name = trim($oid_value->getValue());

                    // ===== TAMBAHAN: format interface GPON =====
                    $iface = null;
                    if ($slot_calc !== null && $port_calc !== null) {
                        $iface = "gpon-onu_1/{$slot_calc}/{$port_calc}:{$onuId}";
                    }
                    // ==========================================

                    $txtData[$key] = array(
                        'name'      => $name,
                        'slot'      => $slot_calc,
                        'port'      => $port_calc,
                        'interface' => $iface
                    );
                    // ===================================================

                    $no++;
                }
            }
        } catch (\Exception $e) {
            $data[] = array(
                'no' => $no,
                'nilai' => 'Gagal mengambil nilai',
                'onu_id' => '',
            );
            $no++;
        }
    }

    // ===== TAMBAHAN: simpan ke file TXT =====
    file_put_contents(
        'onu_index_map.txt',
        json_encode($txtData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
    );
    // =======================================

    return $data;
}





function getDes() {
    global $ip, $port, $community;
    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);
    $oids = array(
        '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.3',
    );
    $data = array();
    $no = 1;
    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);
            if (!$walk->hasOids()) {
                $data[] = array(
                    'no' => $no,
                    'nilai' => 'Tidak ada data',
                    'onu_id' => '',
                );
                $no++;
            } else {
                while ($walk->hasOids()) {
                    $oid_value = $walk->next();
                    $oid_parts = explode('.', $oid_value->getOid());
                    array_shift($oid_parts); // Hilangkan OID utama
                    $onu_id = $oid_value;
                    $data[] = array(
                        'no' => $no,
                        'nilai' => $oid_value->getValue(),
                        'onu_id' => $onu_id,
                    );
                    $no++;
                }
            }
        } catch (\Exception $e) {
            $data[] = array(
                'no' => $no,
                'nilai' => 'Gagal mengambil nilai',
                'onu_id' => '',
            );
            $no++;
        }
    }
    return $data;
}

function getGpononu() {
    global $ip, $port, $community;

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    $baseOid = '1.3.6.1.4.1.3902.1012.3.28.1.1.1';
    $currentOid = $baseOid;
    $data = [];
    $no = 1;

    while (true) {

        //---------------------------------------------------------
        // AUTO RECONNECT — jika SNMP timeout atau koneksi putus
        //---------------------------------------------------------
        $attempt = 0;
        retry_snmp:
        try {
            $res = $snmp->getNext($currentOid);
        } catch (\Exception $e) {
            $attempt++;

            // Jika koneksi putus, tunggu lalu ulangi getNext
            if ($attempt <= 5) {
                sleep(1);
                goto retry_snmp;
            } else {
                break; // putus total
            }
        }
        //---------------------------------------------------------

        $arr = $res->toArray();
        if (empty($arr)) break;

        $val = $arr[0];
        $oid = $val->getOid();

        // Subtree check lebih aman
        if (!preg_match('/^' . str_replace('.', '\.', $baseOid) . '(\.|$)/', $oid)) {
            break;
        }

        // Parsing index
        $itemValue = str_replace($baseOid . '.', '', $oid);
        $parts = explode('.', $itemValue);
        $onuIndex = $parts[0];

        // Kalkulasi slot & port
        if ($onuIndex >= 268566784) {
            $slot = floor(($onuIndex - 268566784) / 65536) + 2;
            $port_number = floor((($onuIndex - 268566784) % 65536) / 256) + 1;
        } else {
            $slot = floor(($onuIndex - 268501248) / 65536) + 1;
            $port_number = floor((($onuIndex - 268501248) % 65536) / 256) + 1;
        }

        if ($slot <= 20) {
            $data[] = [
                'no' => $no++,
                'nilai' => 'gpon-onu_1/' . $slot . '/' . $port_number . ':' . $parts[1],
                'onu_id' => $itemValue,
            ];
        }

        // LANJUTKAN KE OID BERIKUTNYA (resume)
        $currentOid = $oid;
    }

    return $data;
}



function getSn() {
    global $ip, $port, $community;
    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    $oids = array(
        '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.18',
    );

    $data = array();
    $no = 1;

    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);
            if (!$walk->hasOids()) {
                $data[] = array(
                    'no' => $no,
                    'nilai' => 'Tidak ada data',
                );
                $no++;
            } else {
                while ($walk->hasOids()) {
                    $oid_value = $walk->next();
                    $data[] = array(
                        'no' => $no,
                        'nilai' => preg_replace('/^\d+,/', '', $oid_value->getValue()),
                    );
                    $no++;
                }
            }
        } catch (\Exception $e) {
            $data[] = array(
                'no' => $no,
                'nilai' => 'Gagal mengambil nilai',
            );
            $no++;
        }
    }

    return $data;
}

function getState() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    $oids = array(
        '1.3.6.1.4.1.3902.1082.500.10.2.3.8.1.4',
    );

    $total_working = 0;
    $total_dyinggasp = 0;
    $total_los = 0;
    $total_offline = 0;

    $data = array();
    $no = 1;

    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);

            if (!$walk->hasOids()) {
                $data[] = array(
                    'no' => $no++,
                    'nilai' => 'Tidak ada data',
                );
                continue;
            }

            while ($walk->hasOids()) {
                $oid_value = $walk->next();
                $onu_id = $oid_value->getOid();
                $nilai = $oid_value->getValue();

                switch ($nilai) {
                    case '4': // WORKING
                        $status = '
                        <span style="
                            display:inline-flex;
                            width:90px;
                            height:30px;
                            justify-content:center;
                            align-items:center;
                            color:#28a745;
                            background-color:rgba(35, 197, 143, .08);
                            border-radius:5px;
                        ">Working</span>';
                        $total_working++;
                        break;

                    case '5': // DYING GASP
                        $status = '
                        <span style="
                            display:inline-flex;
                            width:90px;
                            height:30px;
                            justify-content:center;
                            align-items:center;
                            color:#cccc00;
                            background-color:rgba(255,220,100,.10);
                            border-radius:5px;
                        ">DyingGasp</span>';
                        $total_dyinggasp++;
                        break;

                    case '2': // LOS
                        $status = '
                        <span style="
                            display:inline-flex;
                            width:90px;
                            height:30px;
                            justify-content:center;
                            align-items:center;
                            color:#f14e4e;
                            background-color:rgba(241,78,78,.08);
                            border-radius:5px;
                        ">LOS</span>';
                        $total_los++;
                        break;

                    case '7': // OFFLINE
                        $status = '
                        <span style="
                            display:inline-flex;
                            width:90px;
                            height:30px;
                            justify-content:center;
                            align-items:center;
                            color:#fd7e14;
                            background-color:rgba(253,126,20,.10);
                            border-radius:5px;
                        ">OFFLINE</span>';
                        $total_offline++;
                        break;

                    default:
                        $status = '';
                        break;
                }

                $data[] = array(
                    'no' => $no++,
                    'onu_id' => $onu_id,
                    'status' => $status,
                );
            }

        } catch (\Exception $e) {
            $data[] = array(
                'no' => $no++,
                'nilai' => 'Gagal mengambil nilai',
            );
        }
    }

    // ================= TOTAL =================
    $data['total'] = array(
        'working'    => $total_working,
        'dyinggasp'  => $total_dyinggasp,
        'los'        => $total_los,
        'offline'    => $total_offline,
        'all'        => $total_working + $total_dyinggasp + $total_los + $total_offline,
    );

    return $data;
}


function getLaser() {
    global $ip, $port, $community;

    $snmp = new SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    $oids = [
        '1.3.6.1.4.1.3902.1082.500.20.2.2.2.1.10',
    ];

    $data = [];
    $no = 1;
    $containerWidth = '90px'; // lebar container konsisten

    foreach ($oids as $oid) {
        try {
            $walk = $snmp->walk($oid);

            while ($walk->hasOids()) {
                $oid_value  = $walk->next();
                $oid_string = (string)$oid_value->getOid();
                $raw        = $oid_value->getValue()->getValue();

                // ================= KONVERSI RX =================
                if ($raw < 32768) {
                    $nilai = ($raw * 0.002) - 30.0;
                } elseif ($raw < 65535) {
                    $nilai = (-30 - ((65535 - $raw) * 0.002));
                } else {
                    $nilai = 'N/A';
                }

                // ================= GENERATE BAR =================
                $barHeights = [4, 8, 12, 16];
                $barHtml = '<span style="display:flex;align-items:flex-end;gap:1px;flex-shrink:0;">';

                if ($nilai === 'N/A') {
                    // bar kosong untuk N/A
                    foreach ($barHeights as $height) {
                        $barHtml .= '<span style="
                            width:3px;
                            height:' . $height . 'px;
                            background:rgba(200,200,200,0.2);
                            border-radius:1px;
                        "></span>';
                    }
                    $color = '#f14e4e';
                    $backgroundColor = 'rgba(241,78,78,.08)';
                    $displayValue = 'N/A';
                } else {
                    // bar untuk nilai valid
                    if ($nilai >= -25) {
                        $color = '#28a745';
                        $backgroundColor = 'rgba(40,167,69,.08)';
                        $bars = 4;
                    } elseif ($nilai >= -27.99) {
                        $color = '#c9b800';
                        $backgroundColor = 'rgba(255,220,100,.10)';
                        $bars = 3;
                    } elseif ($nilai >= -29.99) {
                        $color = '#fd7e14';
                        $backgroundColor = 'rgba(253,126,20,.10)';
                        $bars = 2;
                    } else {
                        $color = '#f14e4e';
                        $backgroundColor = 'rgba(241,78,78,.08)';
                        $bars = 1;
                    }

                    foreach ($barHeights as $i => $height) {
                        $opacity = ($i < $bars) ? '1' : '.2';
                        $barHtml .= '<span style="
                            width:3px;
                            height:' . $height . 'px;
                            background:' . $color . ';
                            opacity:' . $opacity . ';
                            border-radius:1px;
                        "></span>';
                    }

                    $displayValue = number_format($nilai, 2) . ' dBm';
                }
                $barHtml .= '</span>';

                // ================= OUTPUT =================
                $data[] = [
                    'no' => $no++,
                    'onu_id' => $oid_string,
                    'nilai' => '
                    <span style="
                        display:flex;
                        align-items:center;
                        justify-content:center; /* teks di tengah */
                        gap:4px;
                        padding:0 4px;
                        height:30px;
                        color:' . $color . ';
                        background:' . $backgroundColor . ';
                        border-radius:5px;
                        font-weight:500;
                        min-width:' . $containerWidth . ';
                        max-width:' . $containerWidth . ';
                        overflow:hidden;
                        white-space:nowrap;
                        font-size:12px;
                    ">
                        ' . $barHtml . '
                        <span>' . $displayValue . '</span>
                    </span>',
                ];
            }

        } catch (\Exception $e) {
            $data[] = [
                'no' => $no++,
                'onu_id' => '',
                'nilai' => 'Gagal mengambil nilai',
            ];
        }
    }

    return $data;
}






?>