<?php
function get_intsn() {
    include 'koneksi.php';

    $timeout = 10;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);

    if (!$fp) {
        return "Koneksi gagal";
    }

    // Baca respons login
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);

    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);

    fwrite($fp, "show pon onu u\r\n");
    $output = "";
    while (!preg_match('/.*#$/', $output)) {
        $output .= fread($fp, 1024);
    }

    $lines = explode("\n", $output);
    $interfaces = array();
    foreach ($lines as $line) {
        if (strpos($line, "gpon-olt") !== false) {
            $parts = preg_split('/\s+/', trim($line));
            $interfaces[] = array($parts[0], $parts[2]);
        }
    }

    $option = '';
    foreach ($interfaces as $gponolt) {
        fwrite($fp, "show running interface " . $gponolt[0] . "\r\n");
        $output = "";
        while (true) {
            $output .= fread($fp, 1024);
            if (preg_match('/.*#$/', $output)) {
                break;
            } elseif (preg_match('/--More--$/', $output)) {
                fwrite($fp, "\r\n");
            }
        }

        $output = str_replace(".*#$", "", $output);
        $output = str_replace("--More--", "", $output);
        $lines = explode("\n", $output);
        $onu_used = array();
        foreach ($lines as $line) {
            if (preg_match('/onu (\d+)/', $line, $matches)) {
                $onu_used[] = (int)$matches[1];
            }
        }

        $onu_all = range(1, 128);
        $onu_empty = array_diff($onu_all, $onu_used);
        sort($onu_empty);
        $GPONOLT = $gponolt[0];
        $SN = $gponolt[1];
        $GPON = str_replace("gpon-olt_", "gpon-onu_", $GPONOLT);
        $ONU = reset($onu_empty);
        $option .= "<option value='" . $GPONOLT . "," . $SN . "," . $GPON . "," . $ONU . "'>" . $GPONOLT . " " . $SN . "</option>";
    }

    fclose($fp);
    return $option;
}

function get_onutype() {
    include 'koneksi.php';

    $timeout = 30;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);

    if (!$fp) {
        return "Koneksi gagal";
    }

    // Baca respons login
    $output = fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    $output = fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    $output = fread($fp, 1024);

    fwrite($fp, "enable\r\n");
    $output = fread($fp, 1024);

    fwrite($fp, "show onu-type gpon\r\n");
    $output = "";
    $start = false;
    $olt_identity = "";
    while (true) {
        $data = fread($fp, 1024);
        $output .= $data;
        if ($start && strpos($data, "#") !== false) {
            $parts = explode("#", $data);
            $olt_identity = trim($parts[0]);
            if (!empty($olt_identity)) {
                break;
            }
        }
        if (strpos($data, "--More--") !== false) {
            $start = true;
            fwrite($fp, "\r\n");
        }
    }

    $lines = explode("\n", $output);
    $onuTypeOutput = "";
    foreach ($lines as $line) {
        if (strpos($line, "ONU type name:") !== false) {
            $onuTypeOutput .= $line . "\n";
        }
    }

    $onuTypeOutput = str_replace("--More--", "", $onuTypeOutput);
    $onuTypeOutput = str_replace("ONU type name: ", "", $onuTypeOutput);
    $onuTypeOutput = str_replace("\x08", "", $onuTypeOutput);

    $onuTypes = explode("\n", trim($onuTypeOutput));
    $option = '';
    foreach ($onuTypes as $ONUTYPE) {
        $ONUTYPE = trim($ONUTYPE);
        if (!empty($ONUTYPE)) {
            $option .= '<option value="' . $ONUTYPE . '">' . $ONUTYPE . '</option>';
        }
    }

    fclose($fp);
    return $option;
}

function get_profiletype() {
    include 'koneksi.php';

    $timeout = 30;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);

    if (!$fp) {
        return "Koneksi gagal";
    }

    // Baca respons login
    fread($fp, 1024);
    fwrite($fp, $usertel . "\r\n");
    fread($fp, 1024);
    fwrite($fp, $passtel . "\r\n");
    fread($fp, 1024);

    fwrite($fp, "enable\r\n");
    fread($fp, 1024);

    fwrite($fp, "show gpon profile tcont\r\n");
    $output = "";
    $buffer = "";
    $prompt = "";
    while (true) {
        $data = fread($fp, 4096);
        $buffer .= $data;
        if (strpos($data, "--More--") !== false) {
            fwrite($fp, " ");
            $buffer = str_replace("--More--", "", $buffer);
        }
        if (strpos($data, "#") !== false && empty($prompt)) {
            $parts = explode("#", $data);
            $prompt = trim($parts[0]);
        }
        if (strpos($data, "#") !== false && substr($data, -strlen($prompt . "#")) === $prompt . "#") {
            $output .= $buffer;
            break;
        }
    }

    $lines = explode("\n", $output);
    $profileNames = array();
    foreach ($lines as $line) {
        if (strpos($line, "Profile name :") !== false) {
            $profileName = trim(str_replace("Profile name :", "", $line));
            $profileNames[] = $profileName;
        }
    }

    fclose($fp);
    $option = '';
    foreach ($profileNames as $profileName) {
        $profileName = trim($profileName);
        if (!empty($profileName)) {
            $option .= '<option value="' . $profileName . '">' . $profileName . '</option>';
        }
    }
    return $option;
}

function get_profile_vlan() {
    include 'koneksi.php';
    $timeout = 30;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);
    if (!$fp) {
        return "Koneksi gagal";
    } else {
        // Baca respons login
        fread($fp, 1024);
        fwrite($fp, $usertel . "\r\n");
        fread($fp, 1024);
        fwrite($fp, $passtel . "\r\n");
        fread($fp, 1024);
        fwrite($fp, "enable\r\n");
        fread($fp, 1024);
        fwrite($fp, "show gpon onu profile vlan\r\n");
        $output = "";
        $buffer = "";
        $prompt = "";
        while (true) {
            $data = fread($fp, 4096);
            $buffer .= $data;
            if (strpos($data, "--More--") !== false) {
                fwrite($fp, " ");
                $buffer = str_replace("--More--", "", $buffer);
            }
            if (strpos($data, "#") !== false && empty($prompt)) {
                $parts = explode("#", $data);
                $prompt = trim($parts[0]);
            }
            if (strpos($data, "#") !== false && substr($data, -strlen($prompt . "#")) === $prompt . "#") {
                $output .= $buffer;
                break;
            }
        }
        $lines = explode("\n", $output);
        $PROFILEVLAN = array();
        foreach ($lines as $line) {
            if (strpos($line, "Profile name") !== false) {
                $PROFILEVLAN[] = trim(str_replace("Profile name:", "", $line));
            }
        }
        fclose($fp);
        $option = '';
        foreach ($PROFILEVLAN as $profilevlan) {
            $profilevlan = trim($profilevlan);
            if (!empty($profilevlan)) {
                $option .= '<option value="' . $profilevlan . '">' . $profilevlan . '</option>';
            }
        }
        return $option;
    }
}

function get_profile_ip() {
    include 'koneksi.php';
    $timeout = 30;
    $fp = fsockopen($ip, $porttel, $errno, $errstr, $timeout);
    if (!$fp) {
        return "Koneksi gagal";
    } else {
        // Baca respons login
        fread($fp, 1024);
        fwrite($fp, $usertel . "\r\n");
        fread($fp, 1024);
        fwrite($fp, $passtel . "\r\n");
        fread($fp, 1024);
        fwrite($fp, "enable\r\n");
        fread($fp, 1024);
        fwrite($fp, "show gpon onu profile ip\r\n");
        $output = "";
        $buffer = "";
        $prompt = "";
        while (true) {
            $data = fread($fp, 4096);
            $buffer .= $data;
            if (strpos($data, "--More--") !== false) {
                fwrite($fp, " ");
                $buffer = str_replace("--More--", "", $buffer);
            }
            if (strpos($data, "#") !== false && empty($prompt)) {
                $parts = explode("#", $data);
                $prompt = trim($parts[0]);
            }
            if (strpos($data, "#") !== false && substr($data, -strlen($prompt . "#")) === $prompt . "#") {
                $output .= $buffer;
                break;
            }
        }
        $lines = explode("\n", $output);
        $PROFILEIP = array();
        foreach ($lines as $line) {
            if (strpos($line, "Profile name") !== false) {
                $PROFILEIP[] = trim(str_replace("Profile name:", "", $line));
            }
        }
        fclose($fp);
        $option = '';
        foreach ($PROFILEIP as $profileip) {
            $profileip = trim($profileip);
            if (!empty($profileip)) {
                $option .= '<option value="' . $profileip . '">' . $profileip . '</option>';
            }
        }
        return $option;
    }
}
?>