<?php
require 'vendor/autoload.php';
require 'koneksi.php';
use FreeDSx\Snmp\SnmpClient;


function getName($slot = null, $port_number = null, $maxOnu = 128) {
    global $ip, $port, $community;

    // Ambil filter dari query string jika ada
    if (isset($_GET['slot']) && is_numeric($_GET['slot'])) {
        $slot = (int) $_GET['slot'];
    }

    if (isset($_GET['port']) && is_numeric($_GET['port'])) {
        $port_number = (int) $_GET['port'];
    }

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    // ================== BACA FILE TXT ==================
    $mapFile = 'onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return [[
            'no' => 1,
            'nilai' => 'File index tidak ditemukan',
            'onu_id' => '',
        ]];
    }

    $mapData = json_decode(file_get_contents($mapFile), true);
    if (!is_array($mapData)) {
        return [[
            'no' => 1,
            'nilai' => 'File index rusak',
            'onu_id' => '',
        ]];
    }
    // ===================================================

    // ===== AMBIL BASEINDEX PORT (TANPA .ONU) =====
    $baseIndex = null;

    foreach ($mapData as $key => $info) {
        if (
            isset($info['slot'], $info['port']) &&
            (int)$info['slot'] === (int)$slot &&
            (int)$info['port'] === (int)$port_number
        ) {
            // contoh: 285278736 dari 285278736.33
            list($baseIndex,) = explode('.', $key);
            break; // cukup SATU baseIndex port
        }
    }

    if (!$baseIndex) {
        return [[
            'no' => 1,
            'nilai' => "BaseIndex slot $slot port $port_number tidak ditemukan",
            'onu_id' => '',
        ]];
    }
    // ==============================================

    // ===== OID SESUAI INDEX TXT =====
    $baseOid = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.2.' . $baseIndex;

    $data = [];
    $outputTxt = []; // ← penampung output JSON TXT
    $no = 1;

    try {
        $walk = $snmp->walk($baseOid);

        if (!$walk->hasOids()) {
            return [[
                'no' => 1,
                'nilai' => 'Tidak ada data',
                'onu_id' => '',
            ]];
        }

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            $oidParts = explode('.', $oidValue->getOid());
            $onuId = (int) end($oidParts);

            if ($onuId > $maxOnu) {
                continue;
            }

            $key = $baseIndex . '.' . $onuId;

            $row = [
                'no'        => $no++,
                'name'      => $mapData[$key]['name'] ?? '(unknown)',
                'slot'      => $slot,
                'port'      => $port_number,
                'interface' => $mapData[$key]['interface'] ?? "gpon-onu_1/$slot/$port_number:$onuId",
                'nilai'     => $oidValue->getValue(),
                'onu_id'    => $oidValue->getOid(),
            ];

            $data[] = $row;

            // ===== SIMPAN KE OUTPUT TXT =====
            $outputTxt[$key] = [
                'name'      => $row['name'],
                'slot'      => $slot,
                'port'      => $port_number,
                'interface' => $row['interface'],
                'nilai'     => $row['nilai']
            ];
        }

        // ===== TULIS FILE OUTPUT WALK =====
        //file_put_contents(
        //    "onu_walk_slot{$slot}_port{$port_number}.txt",
        //    json_encode($outputTxt, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
        //);

    } catch (\Exception $e) {
        $data[] = [
            'no' => $no,
            'nilai' => 'Gagal mengambil nilai: ' . $e->getMessage(),
            'onu_id' => '',
        ];
    }

    return $data;
}






function getDes($slot = null, $port_number = null, $maxOnu = 128) {
    global $ip, $port, $community;

    // Ambil filter dari query string jika ada
    if (isset($_GET['slot']) && is_numeric($_GET['slot'])) {
        $slot = (int) $_GET['slot'];
    }

    if (isset($_GET['port']) && is_numeric($_GET['port'])) {
        $port_number = (int) $_GET['port'];
    }

    // ================== BACA FILE TXT ==================
    $mapFile = 'onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return [[
            'no' => 1,
            'nilai' => 'File index tidak ditemukan',
            'onu_id' => '',
        ]];
    }

    $mapData = json_decode(file_get_contents($mapFile), true);
    if (!is_array($mapData)) {
        return [[
            'no' => 1,
            'nilai' => 'File index rusak',
            'onu_id' => '',
        ]];
    }
    // ===================================================

    // ===== AMBIL BASEINDEX SESUAI SLOT & PORT =====
    $baseIndex = null;

    foreach ($mapData as $key => $info) {
        if (
            isset($info['slot'], $info['port']) &&
            (int)$info['slot'] === (int)$slot &&
            (int)$info['port'] === (int)$port_number
        ) {
            // ambil 285278736 dari 285278736.33
            list($baseIndex,) = explode('.', $key);
            break;
        }
    }

    if (!$baseIndex) {
        return [[
            'no' => 1,
            'nilai' => "BaseIndex Deskripsi tidak ditemukan (slot $slot port $port_number)",
            'onu_id' => '',
        ]];
    }
    // ===============================================

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    // ================= BASE OID DES =================
    // (OID sama dengan getName sesuai kode awal)
    $baseOid = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.3.' . $baseIndex;

    $data = [];
    $no = 1;

    try {
        $walk = $snmp->walk($baseOid);

        if (!$walk->hasOids()) {
            $data[] = [
                'no' => $no,
                'nilai' => 'Tidak ada data',
                'onu_id' => '',
            ];
        } else {
            while ($walk->hasOids()) {
                $oidValue  = $walk->next();
                $oidString = (string) $oidValue->getOid();

                // ONU number dari sub-index terakhir
                $oidParts = explode('.', $oidString);
                $onuId = (int) end($oidParts);

                if ($onuId < 1 || $onuId > $maxOnu) continue;

                $key = $baseIndex . '.' . $onuId;

                $data[] = [
                    'no'        => $no++,
                    'onu_id'    => $oidString,
                    'interface' => $mapData[$key]['interface']
                                   ?? "gpon-onu_1/$slot/$port_number:$onuId",
                    'nilai'     => trim((string) $oidValue->getValue()), // ✅ DES ASLI
                ];
                
            }
        }

    } catch (\Exception $e) {
        $data[] = [
            'no' => $no,
            'nilai' => 'Gagal mengambil nilai: ' . $e->getMessage(),
            'onu_id' => '',
        ];
    }

    return $data ?: [[
        'no' => 1,
        'nilai' => 'Tidak ada data',
        'onu_id' => '',
    ]];
}













function getSn($slot = null, $port_number = null, $maxOnu = 128) {
    global $ip, $port, $community;

    // Ambil filter dari query string jika ada
    if (isset($_GET['slot']) && is_numeric($_GET['slot'])) {
        $slot = (int) $_GET['slot'];
    }

    if (isset($_GET['port']) && is_numeric($_GET['port'])) {
        $port_number = (int) $_GET['port'];
    }

    // ================== BACA FILE TXT ==================
    $mapFile = 'onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return [[
            'no' => 1,
            'nilai' => 'File index tidak ditemukan',
            'onu_id' => '',
        ]];
    }

    $mapData = json_decode(file_get_contents($mapFile), true);
    if (!is_array($mapData)) {
        return [[
            'no' => 1,
            'nilai' => 'File index rusak',
            'onu_id' => '',
        ]];
    }
    // ===================================================

    // ===== AMBIL BASEINDEX SESUAI SLOT & PORT =====
    $baseIndex = null;

    foreach ($mapData as $key => $info) {
        if (
            isset($info['slot'], $info['port']) &&
            (int)$info['slot'] === (int)$slot &&
            (int)$info['port'] === (int)$port_number
        ) {
            // ambil 285278736 dari 285278736.33
            list($baseIndex,) = explode('.', $key);
            break; // cukup satu
        }
    }

    if (!$baseIndex) {
        return [[
            'no' => 1,
            'nilai' => "Base index SN tidak ditemukan untuk slot $slot port $port_number",
            'onu_id' => '',
        ]];
    }
    // ===============================================

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    // ✅ OID SN (sesuai ZTE)
    $baseOid = '1.3.6.1.4.1.3902.1082.500.10.2.3.3.1.18.' . $baseIndex;

    $data = [];
    $no = 1;

    try {
        $walk = $snmp->walk($baseOid);

        if (!$walk->hasOids()) {
            return [[
                'no' => 1,
                'nilai' => 'Tidak ada data',
                'onu_id' => '',
            ]];
        }

        while ($walk->hasOids()) {
            $oidValue = $walk->next();

            $oidParts = explode('.', $oidValue->getOid());
            $onu_id = (int) end($oidParts);

            if ($onu_id < 1 || $onu_id > $maxOnu) {
                continue;
            }

            // SN biasanya "INTEGER,STRING" → ambil string
            $sn = preg_replace('/^\d+,/', '', $oidValue->getValue());

            $key = $baseIndex . '.' . $onu_id;

            $data[] = [
                'no'        => $no++,
                'slot'      => $slot,
                'port'      => $port_number,
                'onu_id'    => $onu_id,
                'interface' => $mapData[$key]['interface'] ?? "gpon-onu_1/$slot/$port_number:$onu_id",
                'nilai'     => $sn,
            ];
        }

    } catch (\Exception $e) {
        $data[] = [
            'no' => $no,
            'nilai' => 'Gagal mengambil SN: ' . $e->getMessage(),
            'onu_id' => '',
        ];
    }

    return $data;
}







function getState($slot = null, $port_number = null, $maxOnu = 128) {
    global $ip, $port, $community;

    // Ambil filter dari query string jika ada
    if (isset($_GET['slot']) && is_numeric($_GET['slot'])) {
        $slot = (int) $_GET['slot'];
    }

    if (isset($_GET['port']) && is_numeric($_GET['port'])) {
        $port_number = (int) $_GET['port'];
    }

    // ================== BACA FILE TXT ==================
    $mapFile = 'onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return [[
            'no' => 1,
            'status' => 'File index tidak ditemukan',
            'onu_id' => '',
        ]];
    }

    $mapData = json_decode(file_get_contents($mapFile), true);
    if (!is_array($mapData)) {
        return [[
            'no' => 1,
            'status' => 'File index rusak',
            'onu_id' => '',
        ]];
    }
    // ===================================================

    // ===== AMBIL BASEINDEX SESUAI SLOT & PORT =====
    $baseIndex = null;

    foreach ($mapData as $key => $info) {
        if (
            isset($info['slot'], $info['port']) &&
            (int)$info['slot'] === (int)$slot &&
            (int)$info['port'] === (int)$port_number
        ) {
            // ambil 285278736 dari 285278736.1
            list($baseIndex,) = explode('.', $key);
            break;
        }
    }

    if (!$baseIndex) {
        return [[
            'no' => 1,
            'status' => "Base index State tidak ditemukan untuk slot $slot port $port_number",
            'onu_id' => '',
        ]];
    }
    // ===============================================

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    // ================= BASE OID STATUS ONU =================
    $baseOid = '1.3.6.1.4.1.3902.1082.500.10.2.3.8.1.4.' . $baseIndex;

    // ================= COUNTER (TIDAK DIUBAH) =================
    $total_working   = 0;
    $total_dyinggasp = 0;
    $total_los       = 0;
    $total_offline   = 0;

    $data = [];
    $no = 1;

    try {
        $walk = $snmp->walk($baseOid);

        if (!$walk->hasOids()) {
            $data[] = [
                'no' => $no++,
                'status' => "Tidak ada data",
                'onu_id' => '',
            ];
        } else {
            while ($walk->hasOids()) {
                $oidValue = $walk->next();
                $oidString = (string) $oidValue->getOid();

                // ONU ID dari sub-index terakhir
                $oidParts = explode('.', $oidString);
                $onuId = (int) end($oidParts);

                if ($onuId < 1 || $onuId > $maxOnu) continue;

                $nilai = (string) $oidValue->getValue();
                $status = '';

                switch ($nilai) {
                    case '4':
                        $status = '<span style="display:inline-flex;width:90px;height:30px;justify-content:center;align-items:center;color:#28a745;background-color:rgba(35,197,143,.08);border-radius:5px;">Working</span>';
                        $total_working++;
                        break;

                    case '5':
                        $status = '<span style="display:inline-flex;width:90px;height:30px;justify-content:center;align-items:center;color:#cccc00;background-color:rgba(255,220,100,.10);border-radius:5px;">DyingGasp</span>';
                        $total_dyinggasp++;
                        break;

                    case '2':
                        $status = '<span style="display:inline-flex;width:90px;height:30px;justify-content:center;align-items:center;color:#f14e4e;background-color:rgba(241,78,78,.08);border-radius:5px;">LOS</span>';
                        $total_los++;
                        break;

                    case '7':
                        $status = '<span style="display:inline-flex;width:90px;height:30px;justify-content:center;align-items:center;color:#fd7e14;background-color:rgba(253,126,20,.10);border-radius:5px;">OFFLINE</span>';
                        $total_offline++;
                        break;

                    default:
                        $status = '';
                        break;
                }

                $data[] = [
                    'no'        => $no++,
                    'onu_id'    => $oidString, // OID lengkap
                    'interface' => $mapData[$baseIndex . '.' . $onuId]['interface']
                                   ?? "gpon-onu_1/$slot/$port_number:$onuId",
                    'status'    => $status,
                ];
            }
        }

    } catch (\Exception $e) {
        $data[] = [
            'no' => $no++,
            'status' => 'Gagal mengambil nilai: ' . $e->getMessage(),
            'onu_id' => '',
        ];
    }

    // ================= TOTAL (TIDAK DIUBAH) =================
    $data['total'] = [
        'working'    => $total_working,
        'dyinggasp'  => $total_dyinggasp,
        'los'        => $total_los,
        'offline'    => $total_offline,
        'all'        => $total_working + $total_dyinggasp + $total_los + $total_offline,
    ];

    return $data;
}






function getLaser($slot = null, $port_number = null, $maxOnu = 128) {
    global $ip, $port, $community;

    // Ambil filter dari query string jika ada
    if (isset($_GET['slot']) && is_numeric($_GET['slot'])) {
        $slot = (int) $_GET['slot'];
    }

    if (isset($_GET['port']) && is_numeric($_GET['port'])) {
        $port_number = (int) $_GET['port'];
    }

    // ================== BACA FILE TXT ==================
    $mapFile = 'onu_index_map.txt';
    if (!file_exists($mapFile)) {
        return [[
            'no' => 1,
            'nilai' => 'File index tidak ditemukan',
            'onu_id' => '',
        ]];
    }

    $mapData = json_decode(file_get_contents($mapFile), true);
    if (!is_array($mapData)) {
        return [[
            'no' => 1,
            'nilai' => 'File index rusak',
            'onu_id' => '',
        ]];
    }
    // ===================================================

    // ===== AMBIL BASEINDEX SESUAI SLOT & PORT =====
    $baseIndex = null;

    foreach ($mapData as $key => $info) {
        if (
            isset($info['slot'], $info['port']) &&
            (int)$info['slot'] === (int)$slot &&
            (int)$info['port'] === (int)$port_number
        ) {
            // ambil 285278736 dari 285278736.33
            list($baseIndex,) = explode('.', $key);
            break; // cukup SATU
        }
    }

    if (!$baseIndex) {
        return [[
            'no' => 1,
            'nilai' => "Base index Laser tidak ditemukan untuk slot $slot port $port_number",
            'onu_id' => '',
        ]];
    }
    // ===============================================

    $snmp = new \FreeDSx\Snmp\SnmpClient([
        'host' => $ip,
        'port' => $port,
        'community' => $community,
    ]);

    // ================= BASE OID LASER RX =================
    $baseOid = '1.3.6.1.4.1.3902.1082.500.20.2.2.2.1.10.' . $baseIndex;

    $data = [];
    $no = 1;
    $containerWidth = '90px'; // TIDAK DIUBAH

    try {
        $walk = $snmp->walk($baseOid);

        while ($walk->hasOids()) {
            $oidValue  = $walk->next();
            $oidString = (string) $oidValue->getOid();
            $raw       = $oidValue->getValue()->getValue();

            // ================= ONU ID =================
            $oidParts = explode('.', $oidString);
            $onuId = (int) end($oidParts);

            if ($onuId < 1 || $onuId > $maxOnu) {
                continue;
            }

            // ================= KONVERSI RX =================
            if ($raw < 32768) {
                $nilai = ($raw * 0.002) - 30.0;
            } elseif ($raw < 65535) {
                $nilai = (-30 - ((65535 - $raw) * 0.002));
            } else {
                $nilai = 'N/A';
            }

            // ================= GENERATE BAR (TIDAK DIUBAH) =================
            $barHeights = [4, 8, 12, 16];
            $barHtml = '<span style="display:flex;align-items:flex-end;gap:1px;flex-shrink:0;">';

            if ($nilai === 'N/A') {
                foreach ($barHeights as $height) {
                    $barHtml .= '<span style="
                        width:3px;
                        height:' . $height . 'px;
                        background:rgba(200,200,200,0.2);
                        border-radius:1px;
                    "></span>';
                }
                $color = '#f14e4e';
                $backgroundColor = 'rgba(241,78,78,.08)';
                $displayValue = 'N/A';
            } else {
                if ($nilai >= -25) {
                    $color = '#28a745';
                    $backgroundColor = 'rgba(40,167,69,.08)';
                    $bars = 4;
                } elseif ($nilai >= -27.99) {
                    $color = '#c9b800';
                    $backgroundColor = 'rgba(255,220,100,.10)';
                    $bars = 3;
                } elseif ($nilai >= -29.99) {
                    $color = '#fd7e14';
                    $backgroundColor = 'rgba(253,126,20,.10)';
                    $bars = 2;
                } else {
                    $color = '#f14e4e';
                    $backgroundColor = 'rgba(241,78,78,.08)';
                    $bars = 1;
                }

                foreach ($barHeights as $i => $height) {
                    $opacity = ($i < $bars) ? '1' : '.2';
                    $barHtml .= '<span style="
                        width:3px;
                        height:' . $height . 'px;
                        background:' . $color . ';
                        opacity:' . $opacity . ';
                        border-radius:1px;
                    "></span>';
                }

                $displayValue = number_format($nilai, 2) . ' dBm';
            }
            $barHtml .= '</span>';

            // ================= OUTPUT =================
            $key = $baseIndex . '.' . $onuId;

            $data[] = [
                'no'        => $no++,
                'slot'      => $slot,
                'port'      => $port_number,
                'onu_id'    => $oidString,
                'interface' => $mapData[$key]['interface'] ?? "gpon-onu_1/$slot/$port_number:$onuId",
                'nilai'     => '
                <span style="
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    gap:4px;
                    padding:0 4px;
                    height:30px;
                    color:' . $color . ';
                    background:' . $backgroundColor . ';
                    border-radius:5px;
                    font-weight:500;
                    min-width:' . $containerWidth . ';
                    max-width:' . $containerWidth . ';
                    overflow:hidden;
                    white-space:nowrap;
                    font-size:12px;
                ">
                    ' . $barHtml . '
                    <span>' . $displayValue . '</span>
                </span>',
            ];
        }

    } catch (\Exception $e) {
        $data[] = [
            'no' => 1,
            'nilai' => 'Gagal mengambil nilai: ' . $e->getMessage(),
            'onu_id' => '',
        ];
    }

    return $data ?: [[
        'no' => 1,
        'nilai' => 'Tidak ada data',
        'onu_id' => '',
    ]];
}










?>