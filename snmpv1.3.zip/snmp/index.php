<?php 
session_start();
require 'koneksi.php';
if (!isset($_SESSION['username'])) { 
  header("Location: login.php");
  exit;
}
// Hitung total tiket
$total = 0;
if($conn){ // cek koneksi
    $totalResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM tickets");
    if($totalResult && $rowTotal = mysqli_fetch_assoc($totalResult)){
        $total = $rowTotal['total'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title></title>
    <!-- TABLE STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>



    <div class="header"> 
  <div class="d-flex justify-content-between align-items-center position-relative">
    <button class="btn btn-sm btn-dark d-md-none" id="toggle-sidebar">
      <span style="font-size: 18px; color: silver;">&#9776;</span>
    </button>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle-no-caret p-0" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <span class="position-relative status-item">
        <i class="fa fa-bell" style="color: silver;"></i>
      <span class="position-absolute top-0 end-0 rounded-circle animate-pulse" style="top: 0px; right: -2px; width: 8px; height: 8px; background-color: red; border-radius: 50%;"></span>
      </span>
      </a>
      <div class="dropdown-menu dropdown-menu-dark dropdown-menu-right" aria-labelledby="navbarDropdown">
        <li class="dropdown-item" href="#" id="biewMsgBtn"><i class="fa fa-comments"></i> Pesan</li>
        <li class="dropdown-item" href="#" id="viewTicketBtn"><i class="fas fa-ticket-alt"></i> Tiket <span class="badge badge-danger"><?php echo $total; ?></span></li>
        <li class="dropdown-item" href="#" id="viewabtBtn"><i class="fa fa-info"></i> About</li>
      </div>
    </div>
    <div class="nav-item dropdown ml-3"> 
      <a class="nav-link dropdown-toggle-no-caret" href="#" id="navbarDropdownProfile" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-user" style="color: silver;"></i>
      </a>
      <div class="dropdown-menu dropdown-menu-dark dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
        <li class="dropdown-item" href="#"><i class="fa fa-user"></i> Profile</li>
        <li class="dropdown-item" href="#"><i class="fa fa-gear"></i> Settings</li>
        <li class="dropdown-item"><a href="logout.php" style="text-decoration: none"><i class="fa fa-sign-out"></i> Logout</a></li>
      </div>
    </div>
  </div>
</div>




  <!-- Filter Slot port set -->
<div class="status mb-3">
  <div class="d-flex align-items-end gap-3 mb-2" style="flex-wrap: nowrap; overflow-x: auto;">

    <!-- Filter Slot -->
    <div class="form-group" style="flex: 1 1 150px; min-width: 150px;">
      <label for="slotSelect" class="form-label" style="color:#f0f0f0; font-weight: 500;">Slot</label>
      <select id="slotSelect" class="form-select form-select-sm" style="
        background-color: #141b2d;
        color: #f0f0f0;
        border: 1px solid #555;
        border-radius: 0.5rem;
        height: 36px;
        font-size: 0.875rem;
        padding-left: 0.5rem;
        width: 100%;
        min-width: 150px;
      ">
        <option value="" selected>All</option>
      </select>
    </div>

    <!-- Filter Port -->
    <div class="form-group" style="flex: 1 1 180px; min-width: 180px;">
      <label for="portSelect" class="form-label" style="color:#f0f0f0; font-weight: 500;">Port</label>
      <select id="portSelect" class="form-select form-select-sm" style="
        background-color: #141b2d;
        color: #f0f0f0;
        border: 1px solid #555;
        border-radius: 0.5rem;
        height: 36px;
        font-size: 0.875rem;
        padding-left: 0.5rem;
        width: 100%;
        min-width: 180px;
      ">
        <option value="" selected>All</option>
      </select>
    </div>

    <!-- Tombol modal -->
    <div class="form-group" style="flex: 0 0 auto; align-self:flex-end;">
    <button id="openPortModal" class="btn btn-sm mr-2" style="background: none; border: none; padding: 0; position: relative; top: -5px; right: -5px;"><i class="fa fa-gear" style="color:silver;"></i></button>
    </div>

  </div>

  <!-- Tombol Cek Wah -->
  <button id="loadData" type="button" class="btn btn-primary btn-sm mt-2" style="
    background-color: #7e3af2;
    border-color: #7e3af2;
    color: #fff;
    width: 120px;  
    height: 36px;  
  ">
    <i class="fa fa-table"></i> Cek Wah
  </button>
</div>





<!-- Modal Port -->
<div class="modal" id="portModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center;">
  <div style="background:#141b2d; padding:20px; border-radius:0.5rem; min-width:300px; color:#f0f0f0;">
    <h5>Port: <span id="modalPortLabel"></span></h5>
    <!-- Form Nama Port -->
    <input type="text" id="portName" class="form-control form-control-sm mb-2" placeholder="Masukkan nama port" style="background:#1f2a40; color:#f0f0f0; border:1px solid #555;">
    <!-- Tombol Simpan/Edit/Hapus/Tutup -->
    <div style="display:flex; gap:5px; justify-content:flex-end;">
      <button id="createPort" class="btn btn-success btn-sm">Simpan</button>
      <button id="deletePort" class="btn btn-danger btn-sm">Hapus</button>
      <button id="closePortModal" class="btn btn-secondary btn-sm">Tutup</button>
    </div>
  </div>
</div>









<div class="container">
  <div class="sidebar" id="sidebar">
    <ul class="nav flex-column">
      <li class="nav-item">
      <a class="nav-link text-white" href="index.php"><i class="fa fa-home"></i> Dashboard</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="connection.php"><i class="fa fa-plug"></i> Connection</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="activation.php"><i class="fa fa-power-off"></i> Activation</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="users.php"><i class="fa fa-users"></i> Users</a>
      </li>
    </ul>
  </div>
  <div class="content">

<div id="hasilData"></div>

</div>
</div>

<div class="footer">
  <p>&copy; 2025 Muhammad Ilham | Pancor Sanggeng. All rights reserved.</p>
  <span class="version">v1.2</span>
</div>

<!-- Modal Tambah Tiket -->
<div class="modal fade" id="addTicketModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-dark"> <!-- semua teks hitam -->
      <form id="addTicketForm">
        <div class="modal-header">
          <h5 class="modal-title" style="font-weight: normal;">Tambah Tiket Gangguan</h5>
          <button type="button" class="close" data-dismiss="modal" style="color: black; font-weight: normal;">&times;</button>
        </div>
        <div class="modal-body" style="font-weight: normal;">
          <div class="form-group">
            <label>Judul</label>
            <input type="text" name="title" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control" rows="3" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Modal Lihat Tiket -->
<div class="modal fade" id="viewTicketModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content text-dark">
      <div class="modal-header d-flex justify-content-between align-items-center">
        <h5 class="modal-title">Daftar Tiket Gangguan</h5>
        <button type="button" class="btn btn-success btn-sm" id="showAddTicketFormBtn">
          Buat Tiket
        </button>
        <button type="button" class="close ml-2" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <!-- Form Buat Tiket (tersembunyi awalnya) -->
        <div id="addTicketFormContainer" class="mb-3" style="display:none;">
          <form id="addTicketFormInline">
            <div class="form-group">
              <input type="text" class="form-control mb-1" name="title" placeholder="Judul Tiket" required>
              <textarea class="form-control mb-1" name="description" rows="2" placeholder="Deskripsi" required></textarea>
              <button type="submit" class="btn btn-success btn-sm">Masukan Tiket</button>
            </div>
          </form>
          <hr>
        </div>
        <!-- Daftar tiket -->
        <div id="ticketList">
          <!-- Daftar tiket akan dimuat via AJAX -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary ml-auto" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Update Tiket -->
<div class="modal fade" id="updateTicketModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title">Update Tiket Gangguan</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <!-- Form Update Tiket -->
        <form id="updateTicketForm">
          <input type="hidden" name="id" id="updateTicketId"> <!-- ID tiket -->
          <div class="form-group">
            <label for="updateTitle">Judul</label>
            <input type="text" class="form-control" id="updateTitle" name="title" required>
          </div>
          <div class="form-group">
            <label for="updateDescription">Deskripsi</label>
            <textarea class="form-control" id="updateDescription" name="description" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-success">Update Tiket</button>
        </form>
        <!-- Daftar tiket untuk memilih edit (opsional) -->
        <div id="ticketList" class="mt-4">
          <!-- Daftar tiket akan muncul di sini via AJAX -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary ml-auto" data-dismiss="modal">Back</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Hapus Tiket -->
<div class="modal fade" id="deleteTicketModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="color: black;"> <!-- semua teks di modal jadi hitam -->
      <form id="deleteTicketForm">
        <div class="modal-header">
          <h5 class="modal-title">Hapus Tiket Gangguan</h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Pilih Tiket</label>
            <select name="ticket_id" class="form-control" id="ticketSelect" required>
              <!-- opsi tiket akan di-load via AJAX -->
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Hapus</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>





<!-- Modal About -->
<div class="modal fade" id="aboutModal" tabindex="-1" role="dialog" aria-labelledby="aboutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content" style="color: black;">
      <div class="modal-header">
        <h5 class="modal-title" id="aboutModalLabel">Tentang Aplikasi</h5>
        <!-- Tombol close Bootstrap 4 -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
        <p>saya membuat aplikasi ini dengan struktur data dan bahasa php native sederhana css dan js dengan library FreeDSX snmp.</p>
        <p>Kamu bisa mengembangkan aplikasi ini sesuai kebutuhan kamu, aplikasi ini juga memiliki banyak fitur seperti bot monitoring telega..., aktivasi onu.. dan kamu mudah refresh onu dengan menekan nilai redamannya...</p>
        <p>saya berharaf aplikasi monitoring olt zte ini bisa membantu kamu untuk mengelola jaringan kamu. mohon dukungan agar saya bisa terus menambahkan kekurangan aplikasi ini.</p>
        <p>support by MUHAMMAD ILHAM S.Kom <br>Contact Whatsapp : 081999379887</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>






<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="js/script.js"></script>



</body>
</html>