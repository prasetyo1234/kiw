<?php 
include 'koneksi.php';

//add
if (isset($_POST['tusername']) && isset($_POST['tpassword'])) {
  $tusername = $_POST['tusername']; 
  $tpassword = $_POST['tpassword']; 
  
  mysqli_query($conn, "INSERT INTO users (username, password) VALUES ('$tusername', '$tpassword')");
  echo "Berhasil Tambah";

}

//update
if (isset($_POST['username']) && isset($_POST['password'])) {
  $id = $_POST['id']; 
  $username = $_POST['username']; 
  $password = $_POST['password']; 
    if (!empty($_POST['password'])) { 
      mysqli_query($conn, "UPDATE users SET username = '$username', password = '$password' WHERE id = '$id'");
      echo "Berhasil Diubah";
    } else { 
      mysqli_query($conn, "UPDATE users SET username = '$username' WHERE id = '$id'");
    } 
}

//delete
if (isset($_POST['iddelete'])) {
  $iddelete = $_POST['iddelete'];
  $query = "DELETE FROM users WHERE id = '$iddelete'";
  mysqli_query($conn, $query);
  echo "ID dihapus";
}


//addcon
if (isset($_POST['ipa']) && isset($_POST['communitya']) && isset($_POST['porta'])) {
  $ipa = $_POST['ipa']; 
  $communitya = $_POST['communitya']; 
  $porta = $_POST['porta'];

  $usertela = $_POST['usertela']; 
  $passtela = $_POST['passtela']; 
  $porttela = $_POST['porttela']; 

  $tokena = $_POST['tokena']; 
  $chatida = $_POST['chatida']; 
  $groupida = $_POST['groupida']; 
  
  mysqli_query($conn, "INSERT INTO snmpwalk (ip, community, port, usertel, passtel, porttel, token, yourid, groupid) VALUES ('$ipa', '$communitya', '$porta', '$usertela', '$passtela', '$porttela', '$tokena', '$chatida', '$groupida')");
  echo "Berhasil Tambah";

}

//updatecon
if (isset($_POST['ip']) && isset($_POST['community']) && isset($_POST['port'])) {
  $idc = $_POST['id']; 
  $ips = $_POST['ip']; 
  $communitys = $_POST['community']; 
  $ports = $_POST['port'];

  $usertelu = $_POST['usertelu']; 
  $passtelu = $_POST['passtelu']; 
  $porttelu = $_POST['porttelu'];

  $tokenu = $_POST['tokenu']; 
  $chatidu = $_POST['chatidu'];
  $groupidu = $_POST['groupidu'];

  mysqli_query($conn, "UPDATE snmpwalk SET ip = '$ips', community = '$communitys', port = '$ports', usertel = '$usertelu', passtel = '$passtelu', porttel = '$porttelu', token = '$tokenu', yourid = '$chatidu', groupid = '$groupidu' WHERE id = '$idc'");
      echo "Berhasil Diubah";
    }


//deletecon
if (isset($_POST['iddeletes'])) {
  $iddeletes = $_POST['iddeletes'];
  $query = "DELETE FROM snmpwalk WHERE id = '$iddeletes'";
  mysqli_query($conn, $query);
  echo "ID dihapus";
}

//ports
$filename = 'ports.txt';

// Load data dari file TXT ke array associative
$ports = [];
if(file_exists($filename)){
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach($lines as $line){
        list($key,$name) = explode('|', $line);
        $ports[$key] = $name;
    }
}

// Ambil data POST
$data = json_decode(file_get_contents('php://input'), true);

// DELETE
if(isset($data['delete']) && isset($data['key'])){
    unset($ports[$data['key']]);
    savePorts($ports,$filename);
    echo "Port berhasil dihapus!"; exit;
}

// CREATE / SIMPAN
if(isset($data['slot'],$data['port'],$data['name'])){
    $key = $data['slot'].'-'.$data['port'];
    $ports[$key] = $data['name'];
    savePorts($ports,$filename);
    echo "Port berhasil disimpan!"; exit;
}

echo "Data tidak valid!";

// Fungsi simpan array ke TXT
function savePorts($ports, $filename){
    $lines = [];
    foreach($ports as $key=>$name){
        $lines[] = $key.'|'.$name;
    }
    file_put_contents($filename, implode(PHP_EOL, $lines));
}

?>
