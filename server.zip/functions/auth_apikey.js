const { default: Axios} = require('axios');

async function checkApikey(apikey) {
    data = [
        "YOUR-API-KEY" //ubah apikey sesuka anda
    ]
    if (data.includes(apikey)) {
        return true
    } else {
        return false;
    }
}
module.exports = {
    checkApikey
}