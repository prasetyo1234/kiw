const fastify = require('fastify')({ logger: true })
const func_auth = require('./functions/auth_apikey');
const fs = require('fs').promises;
const path = require('path');
const { response } = require('express');
const filePath1 = path.join(__dirname, 'ip.json');

/* 

contoh memanggil Api : 
http://domain.com/listIp?apikey=YOUR-API-KEY 



*/
fastify.get('/', function handler(request, reply) {
    reply.send({ success: true, time: new Date() })
})

fastify.get("/listIp", async (requests, reply) => {
    let apikey = requests.query.apikey;

    if (!apikey) {
        reply.code(400).header('Content-Type', 'text/plain; charset=utf-8').send('Apikey Not Found !')
        return;
    }
    try {
        const isAuthValid = await func_auth.checkApikey(apikey);
        if (!isAuthValid) {
            reply.code(401).header('Content-Type', 'text/plain; charset=utf-8').send('Apikey Not Found')
        } else {
            const filePath = 'ip.json';
            const content = await fs.readFile(filePath, 'utf-8');
            reply.code(200).header('Content-Type', 'text/plain; charset=utf-8').send(content)
        } 
    } catch (err) {
        reply.send(500).header('Content-Type', 'text/plain; charset=utf-8').send(`Error: ${err.message}`);
    }
})


fastify.post('/update-ip-private', async (request, reply) => {
    const { ipLama: oldIP, ipBaru: newIP } = request.body;
  
    try {
      let fileContent1 = await fs.readFile(filePath1, 'utf8');
  
      let updated1 = false;
  
      if (fileContent1.includes(oldIP)) {
        fileContent1 = fileContent1.replace(new RegExp(oldIP, 'g'), newIP);
        await fs.writeFile(filePath1, fileContent1);
        updated1 = true;
        reply.send({ status: 'T', message: 'IP updated in ip.json' });
      } else {
        reply.send({ status: 'F', message: 'Old IP not found in ip.json' });
      }
  
    } catch (error) {
      reply.send({ status: 'F', message: `Error occurred: ${error.message}` });
    }
  });

fastify.post('/add-ip-tele', async (request, reply) => {
    const { ip, id, user_tele } = request.body;
  
    try {
      // Read the current content of the JSON file
      let fileContent = await fs.readFile(filePath1, 'utf8');
      let data = JSON.parse(fileContent);
  
      // Check if the IP already exists
      if (data[ip]) {
        reply.send({ status: 'F', message: 'IP already exists in ip.json' });
      } else {
        data[ip] = { id, user_tele };
  
        await fs.writeFile(filePath1, JSON.stringify(data, null, 2));
        reply.send({ status: 'T', message: 'IP and user details added to ip.json' });
      }
    } catch (error) {
      reply.send({ status: 'F', message: `Error occurred: ${error.message}` });
    }
  });
  
const readData = async () => {
    try {
      const data = await fs.readFile(fileRev, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      // Jika file tidak ditemukan atau terjadi error, kembalikan objek kosong
      if (error.code === 'ENOENT') {
        return {};
      }
      throw error;
    }
  };
  
const writeData = async (data) => {
    await fs.writeFile(fileRev, JSON.stringify(data, null, 2), 'utf8');
  };

fastify.post('/add-ip-revers', async (request, reply) => {
    const { ip, date } = request.body;
  
    if (!ip || !date) {
      return reply.status(400).send({ status: 'F', message: 'IP and date are required' });
    }
  
    try {
      const data = await readData();
  
      if (data[ip]) {
        return reply.status(400).send({ status: 'F', message: 'IP already exists' });
      }
  
      data[ip] = date;
      await writeData(data);
  
      reply.send({ status: 'T', message: 'IP added successfully', data });
    } catch (error) {
      reply.send({ status: 'F', message: `Error occurred: ${error.message}` });
    }
  });


fastify.listen({ host:'0.0.0.0', port: 80 }, (err) => {
    if (err) {
        fastify.log.error(err)
    }
})